import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Child schema
export const children = pgTable("children", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  deviceInfo: text("device_info").notNull(),
  deviceId: text("device_id").notNull().unique(),
  profileImage: text("profile_image"),
  parentId: integer("parent_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChildSchema = createInsertSchema(children).omit({
  id: true,
  createdAt: true,
});

// Location schema
export const locations = pgTable("locations", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  locationName: text("location_name"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertLocationSchema = createInsertSchema(locations).omit({
  id: true,
});

// Safe Zones (Geofencing)
export const safeZones = pgTable("safe_zones", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  childId: integer("child_id").notNull(),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  radius: integer("radius").notNull(),
  active: boolean("active").default(true),
});

export const insertSafeZoneSchema = createInsertSchema(safeZones).omit({
  id: true,
});

// Calls
export const calls = pgTable("calls", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  phoneNumber: text("phone_number").notNull(),
  contactName: text("contact_name"),
  callType: text("call_type").notNull(), // incoming, outgoing, missed
  duration: integer("duration"), // in seconds
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertCallSchema = createInsertSchema(calls).omit({
  id: true,
});

// Messages
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  phoneNumber: text("phone_number").notNull(),
  contactName: text("contact_name"),
  messageType: text("message_type").notNull(), // SMS, WhatsApp, etc.
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
});

// Apps
export const apps = pgTable("apps", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  name: text("name").notNull(),
  packageName: text("package_name").notNull(),
  category: text("category"),
  installDate: timestamp("install_date").defaultNow().notNull(),
  isBlocked: boolean("is_blocked").default(false),
});

export const insertAppSchema = createInsertSchema(apps).omit({
  id: true,
});

// App Usage
export const appUsage = pgTable("app_usage", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  appId: integer("app_id").notNull(),
  duration: integer("duration").notNull(), // in seconds
  date: timestamp("date").defaultNow().notNull(),
});

export const insertAppUsageSchema = createInsertSchema(appUsage).omit({
  id: true,
});

// Web Browsing History
export const browsing = pgTable("browsing", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  url: text("url").notNull(),
  title: text("title"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertBrowsingSchema = createInsertSchema(browsing).omit({
  id: true,
});

// Alerts
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  type: text("type").notNull(), // location, app, browsing, etc.
  severity: text("severity").notNull(), // info, warning, danger
  message: text("message").notNull(),
  details: json("details"),
  read: boolean("read").default(false),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  read: true,
});

// Activities
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  type: text("type").notNull(), // call, message, app, browsing, etc.
  details: json("details").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
});

// Screen Time Limits
export const screenTimeLimits = pgTable("screen_time_limits", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull(),
  dailyLimit: integer("daily_limit").notNull(), // in minutes
  appSpecificLimits: json("app_specific_limits"), // {appId: limitInMinutes}
});

export const insertScreenTimeLimitSchema = createInsertSchema(screenTimeLimits).omit({
  id: true,
});

// Users (Parents) schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  profileImage: text("profile_image"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Child = typeof children.$inferSelect;
export type InsertChild = z.infer<typeof insertChildSchema>;

export type Location = typeof locations.$inferSelect;
export type InsertLocation = z.infer<typeof insertLocationSchema>;

export type SafeZone = typeof safeZones.$inferSelect;
export type InsertSafeZone = z.infer<typeof insertSafeZoneSchema>;

export type Call = typeof calls.$inferSelect;
export type InsertCall = z.infer<typeof insertCallSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type App = typeof apps.$inferSelect;
export type InsertApp = z.infer<typeof insertAppSchema>;

export type AppUsage = typeof appUsage.$inferSelect;
export type InsertAppUsage = z.infer<typeof insertAppUsageSchema>;

export type Browsing = typeof browsing.$inferSelect;
export type InsertBrowsing = z.infer<typeof insertBrowsingSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;

export type ScreenTimeLimit = typeof screenTimeLimits.$inferSelect;
export type InsertScreenTimeLimit = z.infer<typeof insertScreenTimeLimitSchema>;
