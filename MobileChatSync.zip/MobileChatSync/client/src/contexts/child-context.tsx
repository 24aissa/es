import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { Child } from "@shared/schema";

interface ChildContextType {
  selectedChild: Child | null;
  setSelectedChild: (child: Child | null) => void;
  loading: boolean;
}

const ChildContext = createContext<ChildContextType>({
  selectedChild: null,
  setSelectedChild: () => {},
  loading: true,
});

export const useChild = () => useContext(ChildContext);

interface ChildProviderProps {
  children: ReactNode;
}

export const ChildProvider = ({ children }: ChildProviderProps) => {
  const [selectedChild, setSelectedChild] = useState<Child | null>(null);
  const [loading, setLoading] = useState(true);

  // Fetch children for the current parent
  // In a real app, you'd get the parent ID from auth context
  const { data: childrenList = [], isLoading } = useQuery({
    queryKey: ["/api/children?parentId=1"],
  });

  useEffect(() => {
    if (!isLoading && childrenList.length > 0 && !selectedChild) {
      // Automatically select the first child
      setSelectedChild(childrenList[0]);
    }
    setLoading(isLoading);
  }, [childrenList, isLoading, selectedChild]);

  return (
    <ChildContext.Provider value={{ selectedChild, setSelectedChild, loading }}>
      {children}
    </ChildContext.Provider>
  );
};
