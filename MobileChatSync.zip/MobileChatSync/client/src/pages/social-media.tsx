import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { useChild } from "@/contexts/child-context";
import { formatRelativeTime, formatDurationArabic } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function SocialMedia() {
  const { selectedChild } = useChild();
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch apps
  const { data: apps = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/apps`],
    enabled: !!selectedChild?.id,
  });

  // Fetch app usage
  const { data: appUsage = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/app-usage`],
    enabled: !!selectedChild?.id,
  });

  // Filter for social media apps
  const socialMediaApps = apps.filter((app: any) => {
    const name = app.name.toLowerCase();
    return (
      name.includes("instagram") ||
      name.includes("facebook") ||
      name.includes("twitter") ||
      name.includes("tiktok") ||
      name.includes("snapchat") ||
      name.includes("whatsapp") ||
      name.includes("telegram") ||
      name.includes("discord") ||
      name.includes("pinterest") ||
      (app.category && app.category.toLowerCase().includes("تطبيق اجتماعي"))
    );
  });

  // Get app usage data for an app
  const getAppUsage = (appId: number) => {
    return appUsage.find((usage: any) => usage.appId === appId);
  };

  // Get social media app icon
  const getSocialMediaIcon = (app: any) => {
    const name = app.name.toLowerCase();
    if (name.includes("instagram")) return { icon: "photo", color: "bg-gradient-to-br from-purple-500 to-pink-500" };
    if (name.includes("facebook")) return { icon: "thumb_up", color: "bg-gradient-to-br from-blue-500 to-blue-700" };
    if (name.includes("twitter")) return { icon: "trending_up", color: "bg-gradient-to-br from-blue-400 to-blue-500" };
    if (name.includes("tiktok")) return { icon: "videocam", color: "bg-gradient-to-br from-red-500 to-blue-500" };
    if (name.includes("snapchat")) return { icon: "visibility", color: "bg-gradient-to-br from-yellow-300 to-yellow-500" };
    if (name.includes("whatsapp")) return { icon: "message", color: "bg-gradient-to-br from-green-500 to-green-600" };
    if (name.includes("telegram")) return { icon: "send", color: "bg-gradient-to-br from-blue-400 to-blue-500" };
    if (name.includes("discord")) return { icon: "chat", color: "bg-gradient-to-br from-indigo-500 to-indigo-600" };
    if (name.includes("pinterest")) return { icon: "push_pin", color: "bg-gradient-to-br from-red-500 to-red-600" };
    
    // Default
    return { icon: "people", color: "bg-gradient-to-br from-gray-500 to-gray-600" };
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />

      <main className="flex-1 md:mr-64 min-h-screen">
        <Header title="وسائل التواصل الاجتماعي" subtitle="مراقبة نشاط طفلك على منصات التواصل الاجتماعي" />

        <div className="p-4 md:p-6">
          <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
              <TabsTrigger value="activity">النشاط</TabsTrigger>
              <TabsTrigger value="settings">الإعدادات</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Social Media Apps Overview */}
                <div className="lg:col-span-2">
                  <Card className="shadow-sm">
                    <CardHeader className="py-4 px-4 border-b border-slate-100">
                      <CardTitle className="font-semibold flex items-center text-base">
                        <span className="material-icons mr-2 text-primary-500">apps</span>
                        تطبيقات التواصل الاجتماعي المثبتة
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      {socialMediaApps.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {socialMediaApps.map((app: any) => {
                            const { icon, color } = getSocialMediaIcon(app);
                            const usage = getAppUsage(app.id);
                            
                            return (
                              <Card key={app.id} className="shadow-sm hover:shadow-md transition-shadow">
                                <CardContent className="p-4">
                                  <div className="flex items-center">
                                    <div className={`w-12 h-12 rounded-lg ${color} flex items-center justify-center ml-3`}>
                                      <span className="material-icons text-white text-xl">
                                        {icon}
                                      </span>
                                    </div>
                                    <div className="flex-grow">
                                      <h3 className="font-medium">{app.name}</h3>
                                      <p className="text-xs text-slate-500 mt-1">
                                        آخر استخدام: {formatRelativeTime(app.installDate)}
                                      </p>
                                      {usage && (
                                        <p className="text-xs text-primary-600 mt-1">
                                          وقت الاستخدام اليوم: {Math.floor(usage.duration / 60)} دقيقة
                                        </p>
                                      )}
                                    </div>
                                    <div>
                                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                        {app.isBlocked ? "محظور" : "مسموح"}
                                      </Badge>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="text-center py-10 text-slate-500">
                          لم يتم العثور على تطبيقات تواصل اجتماعي مثبتة
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Monitoring Information */}
                  <Card className="shadow-sm mt-6">
                    <CardHeader className="py-4 px-4 border-b border-slate-100">
                      <CardTitle className="font-semibold flex items-center text-base">
                        <span className="material-icons mr-2 text-primary-500">info</span>
                        معلومات المراقبة
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="bg-amber-50 p-4 rounded-lg border border-amber-100">
                        <h3 className="font-medium text-amber-800 flex items-center">
                          <span className="material-icons mr-2 text-amber-600">lightbulb</span>
                          ملاحظة حول مراقبة وسائل التواصل
                        </h3>
                        <p className="text-sm text-amber-700 mt-2">
                          تتيح ميزات المراقبة الأبوية مراقبة وقت استخدام تطبيقات التواصل الاجتماعي ووجودها على الجهاز، 
                          لكن قراءة محتوى المحادثات والمنشورات تتطلب صلاحيات إضافية وقد تؤثر على خصوصية الطفل.
                        </p>
                        <p className="text-sm text-amber-700 mt-2">
                          ينصح بمناقشة استخدام وسائل التواصل الاجتماعي مع طفلك وتثقيفه حول الاستخدام الآمن.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        <div className="border rounded-lg p-4">
                          <h3 className="font-medium flex items-center">
                            <span className="material-icons mr-2 text-primary-500">visibility</span>
                            ما يمكن مراقبته
                          </h3>
                          <ul className="mt-2 space-y-2 text-sm">
                            <li className="flex items-center">
                              <span className="material-icons text-green-600 ml-2 text-sm">check_circle</span>
                              وقت استخدام التطبيقات
                            </li>
                            <li className="flex items-center">
                              <span className="material-icons text-green-600 ml-2 text-sm">check_circle</span>
                              حظر أو السماح بالتطبيقات
                            </li>
                            <li className="flex items-center">
                              <span className="material-icons text-green-600 ml-2 text-sm">check_circle</span>
                              جدولة أوقات الاستخدام
                            </li>
                            <li className="flex items-center">
                              <span className="material-icons text-green-600 ml-2 text-sm">check_circle</span>
                              إشعارات تثبيت تطبيقات جديدة
                            </li>
                          </ul>
                        </div>

                        <div className="border rounded-lg p-4">
                          <h3 className="font-medium flex items-center">
                            <span className="material-icons mr-2 text-red-500">visibility_off</span>
                            ما لا يمكن مراقبته بدون صلاحيات إضافية
                          </h3>
                          <ul className="mt-2 space-y-2 text-sm">
                            <li className="flex items-center">
                              <span className="material-icons text-red-500 ml-2 text-sm">cancel</span>
                              محتوى المحادثات الخاصة
                            </li>
                            <li className="flex items-center">
                              <span className="material-icons text-red-500 ml-2 text-sm">cancel</span>
                              المنشورات والتعليقات
                            </li>
                            <li className="flex items-center">
                              <span className="material-icons text-red-500 ml-2 text-sm">cancel</span>
                              قائمة الأصدقاء والمتابعين
                            </li>
                            <li className="flex items-center">
                              <span className="material-icons text-red-500 ml-2 text-sm">cancel</span>
                              الصور والفيديوهات المشاركة
                            </li>
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                  <Card className="shadow-sm">
                    <CardHeader className="py-4 px-4 border-b border-slate-100">
                      <CardTitle className="font-semibold flex items-center text-base">
                        <span className="material-icons mr-2 text-primary-500">query_stats</span>
                        إحصائيات الاستخدام
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      {socialMediaApps.length > 0 ? (
                        <div className="space-y-4">
                          <div>
                            <h3 className="text-sm font-medium text-slate-700">
                              إجمالي وقت الاستخدام اليوم
                            </h3>
                            <p className="text-2xl font-bold text-primary-600 mt-1">
                              {formatDurationArabic(
                                appUsage
                                  .filter((usage: any) => 
                                    socialMediaApps.some((app: any) => app.id === usage.appId)
                                  )
                                  .reduce((total: number, usage: any) => total + usage.duration, 0)
                              )}
                            </p>
                          </div>

                          <div>
                            <h3 className="text-sm font-medium text-slate-700">
                              عدد التطبيقات المستخدمة
                            </h3>
                            <p className="text-2xl font-bold text-primary-600 mt-1">
                              {socialMediaApps.length}
                            </p>
                          </div>

                          <div>
                            <h3 className="text-sm font-medium text-slate-700">
                              أكثر التطبيقات استخدامًا
                            </h3>
                            {appUsage.length > 0 ? (
                              <div className="mt-2 space-y-2">
                                {appUsage
                                  .filter((usage: any) => 
                                    socialMediaApps.some((app: any) => app.id === usage.appId)
                                  )
                                  .sort((a: any, b: any) => b.duration - a.duration)
                                  .slice(0, 3)
                                  .map((usage: any) => {
                                    const app = socialMediaApps.find((a: any) => a.id === usage.appId);
                                    if (!app) return null;
                                    
                                    return (
                                      <div key={usage.id} className="flex items-center justify-between">
                                        <span className="text-sm">{app.name}</span>
                                        <span className="text-sm font-medium">
                                          {formatDurationArabic(usage.duration)}
                                        </span>
                                      </div>
                                    );
                                  })}
                              </div>
                            ) : (
                              <p className="text-sm text-slate-500 mt-2">
                                لا توجد بيانات استخدام
                              </p>
                            )}
                          </div>
                        </div>
                      ) : (
                        <p className="text-center py-4 text-slate-500">
                          لا توجد بيانات متاحة
                        </p>
                      )}
                    </CardContent>
                  </Card>

                  <Card className="shadow-sm">
                    <CardHeader className="py-4 px-4 border-b border-slate-100">
                      <CardTitle className="font-semibold flex items-center text-base">
                        <span className="material-icons mr-2 text-primary-500">shield</span>
                        الحماية والأمان
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <span className="material-icons text-primary-500 ml-2">block</span>
                            <span className="text-sm">حظر التطبيقات الجديدة</span>
                          </div>
                          <Switch />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <span className="material-icons text-primary-500 ml-2">schedule</span>
                            <span className="text-sm">حدود زمنية للاستخدام</span>
                          </div>
                          <Switch />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <span className="material-icons text-primary-500 ml-2">notifications</span>
                            <span className="text-sm">تنبيهات للنشاط المشبوه</span>
                          </div>
                          <Switch />
                        </div>
                        
                        <Button className="w-full mt-2">
                          <span className="material-icons ml-1 text-sm">settings</span>
                          إعدادات متقدمة
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* Activity Tab */}
            <TabsContent value="activity">
              <Card className="shadow-sm">
                <CardHeader className="py-4 px-4 border-b border-slate-100">
                  <CardTitle className="font-semibold flex items-center text-base">
                    <span className="material-icons mr-2 text-primary-500">update</span>
                    نشاط التواصل الاجتماعي
                  </CardTitle>
                </CardHeader>
                <CardContent className="py-10 text-center text-slate-500">
                  <span className="material-icons text-5xl text-slate-300 mb-4">data_usage</span>
                  <h3 className="text-lg font-medium mb-2">ميزة تتبع النشاط التفصيلي</h3>
                  <p className="max-w-md mx-auto">
                    قريبًا - ستتمكن من مراقبة نشاط طفلك على وسائل التواصل الاجتماعي بشكل أكثر تفصيلًا، بما في ذلك الوقت المستغرق والمحتوى الذي يشاهده.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings">
              <Card className="shadow-sm">
                <CardHeader className="py-4 px-4 border-b border-slate-100">
                  <CardTitle className="font-semibold flex items-center text-base">
                    <span className="material-icons mr-2 text-primary-500">settings</span>
                    إعدادات المراقبة
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-sm font-medium text-slate-700 mb-2">
                        التطبيقات المسموح بها
                      </h3>
                      <div className="space-y-2">
                        {socialMediaApps.map((app: any) => (
                          <div key={app.id} className="flex items-center justify-between p-2 border rounded-lg">
                            <div className="flex items-center">
                              <div className={`w-8 h-8 rounded-full ${getSocialMediaIcon(app).color} flex items-center justify-center ml-2`}>
                                <span className="material-icons text-white text-sm">
                                  {getSocialMediaIcon(app).icon}
                                </span>
                              </div>
                              <span>{app.name}</span>
                            </div>
                            <Switch checked={!app.isBlocked} />
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium text-slate-700 mb-2">
                        حدود الوقت اليومية لوسائل التواصل
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Card className="shadow-sm">
                          <CardContent className="p-4">
                            <div className="flex justify-between items-center">
                              <div>
                                <h4 className="font-medium">أيام الدراسة</h4>
                                <p className="text-sm text-slate-500">الأحد - الخميس</p>
                              </div>
                              <div className="text-right">
                                <span className="text-xl font-bold text-primary-600">60</span>
                                <span className="text-sm text-slate-500"> دقيقة</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        <Card className="shadow-sm">
                          <CardContent className="p-4">
                            <div className="flex justify-between items-center">
                              <div>
                                <h4 className="font-medium">عطلة نهاية الأسبوع</h4>
                                <p className="text-sm text-slate-500">الجمعة - السبت</p>
                              </div>
                              <div className="text-right">
                                <span className="text-xl font-bold text-primary-600">120</span>
                                <span className="text-sm text-slate-500"> دقيقة</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                      <Button variant="outline" className="mt-2 w-full">
                        تعديل حدود الوقت
                      </Button>
                    </div>

                    <div>
                      <h3 className="text-sm font-medium text-slate-700 mb-2">
                        الإشعارات
                      </h3>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">إشعار عند تجاوز الحد اليومي</span>
                          <Switch defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">إشعار عند تثبيت تطبيق جديد</span>
                          <Switch defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">تقرير أسبوعي بالاستخدام</span>
                          <Switch defaultChecked />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
