import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { useChild } from "@/contexts/child-context";
import { formatRelativeTime, formatDurationArabic } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";

export default function Calls() {
  const { selectedChild } = useChild();
  const [filterType, setFilterType] = useState("all"); // 'all', 'incoming', 'outgoing', 'missed'
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch calls with a larger limit for this dedicated page
  const { data: calls = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/calls?limit=50`],
    enabled: !!selectedChild?.id,
  });

  // Filter calls based on filter type and search query
  const filteredCalls = calls.filter((call: any) => {
    const typeMatch =
      filterType === "all" ||
      (filterType === "incoming" && call.callType === "incoming") ||
      (filterType === "outgoing" && call.callType === "outgoing") ||
      (filterType === "missed" && call.callType === "missed");

    const searchMatch =
      searchQuery === "" ||
      (call.contactName &&
        call.contactName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      call.phoneNumber.includes(searchQuery);

    return typeMatch && searchMatch;
  });

  // Get call type icon and color
  const getCallTypeIcon = (callType: string) => {
    switch (callType) {
      case "incoming":
        return {
          icon: "call_received",
          color: "text-primary-500",
          label: "مكالمة واردة",
        };
      case "outgoing":
        return {
          icon: "call_made",
          color: "text-green-500",
          label: "مكالمة صادرة",
        };
      case "missed":
        return {
          icon: "call_missed",
          color: "text-red-500",
          label: "مكالمة فائتة",
        };
      default:
        return {
          icon: "call",
          color: "text-slate-500",
          label: "مكالمة",
        };
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />

      <main className="flex-1 md:mr-64 min-h-screen">
        <Header title="سجل المكالمات" subtitle="عرض جميع مكالمات طفلك" />

        <div className="p-4 md:p-6">
          <Card className="shadow-sm">
            <CardHeader className="py-4 px-4 border-b border-slate-100">
              <CardTitle className="font-semibold flex items-center text-base">
                <span className="material-icons mr-2 text-primary-500">call</span>
                سجل المكالمات
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              {/* Filters */}
              <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="flex-grow relative">
                  <Input
                    type="text"
                    placeholder="بحث عن اسم أو رقم هاتف..."
                    className="w-full pr-8 pl-2 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <span className="material-icons absolute right-2 top-2 text-slate-400 text-sm">
                    search
                  </span>
                </div>
                <div className="w-full md:w-48">
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-full h-9 text-sm bg-slate-50 border border-slate-200 rounded-lg">
                      <SelectValue placeholder="نوع المكالمة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع المكالمات</SelectItem>
                      <SelectItem value="incoming">المكالمات الواردة</SelectItem>
                      <SelectItem value="outgoing">المكالمات الصادرة</SelectItem>
                      <SelectItem value="missed">المكالمات الفائتة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Calls Table */}
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>نوع المكالمة</TableHead>
                      <TableHead>الاسم/الرقم</TableHead>
                      <TableHead>المدة</TableHead>
                      <TableHead>الوقت</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCalls.length > 0 ? (
                      filteredCalls.map((call: any) => {
                        const { icon, color, label } = getCallTypeIcon(call.callType);
                        return (
                          <TableRow key={call.id}>
                            <TableCell>
                              <div className="flex items-center">
                                <span className={`material-icons ${color} ml-2`}>
                                  {icon}
                                </span>
                                <span>{label}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div>
                                <p className="font-medium">
                                  {call.contactName || "رقم غير معروف"}
                                </p>
                                <p className="text-sm text-slate-500">
                                  {call.phoneNumber}
                                </p>
                              </div>
                            </TableCell>
                            <TableCell>
                              {call.duration > 0
                                ? formatDurationArabic(call.duration)
                                : "—"}
                            </TableCell>
                            <TableCell>
                              {formatRelativeTime(call.timestamp)}
                            </TableCell>
                          </TableRow>
                        );
                      })
                    ) : (
                      <TableRow>
                        <TableCell
                          colSpan={4}
                          className="text-center py-6 text-slate-500"
                        >
                          لا توجد مكالمات مطابقة للبحث
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
