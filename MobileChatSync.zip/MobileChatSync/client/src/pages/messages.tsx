import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { useChild } from "@/contexts/child-context";
import { formatRelativeTime } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export default function Messages() {
  const { selectedChild } = useChild();
  const [messageType, setMessageType] = useState("all"); // 'all', 'SMS', 'WhatsApp', etc.
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMessage, setSelectedMessage] = useState<any>(null);

  // Fetch messages with a larger limit for this dedicated page
  const { data: messages = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/messages?limit=50`],
    enabled: !!selectedChild?.id,
  });

  // Filter messages based on type and search query
  const filteredMessages = messages.filter((message: any) => {
    const typeMatch =
      messageType === "all" || message.messageType === messageType;

    const searchMatch =
      searchQuery === "" ||
      (message.contactName &&
        message.contactName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      message.phoneNumber.includes(searchQuery) ||
      message.content.toLowerCase().includes(searchQuery.toLowerCase());

    return typeMatch && searchMatch;
  });

  // Get message type icon based on type
  const getMessageTypeIcon = (type: string) => {
    switch (type) {
      case "WhatsApp":
        return {
          icon: "WhatsApp",
          color: "text-green-500",
        };
      case "SMS":
        return {
          icon: "sms",
          color: "text-blue-500",
        };
      default:
        return {
          icon: "message",
          color: "text-slate-500",
        };
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />

      <main className="flex-1 md:mr-64 min-h-screen">
        <Header title="الرسائل النصية" subtitle="عرض جميع رسائل طفلك" />

        <div className="p-4 md:p-6">
          <Card className="shadow-sm">
            <CardHeader className="py-4 px-4 border-b border-slate-100">
              <CardTitle className="font-semibold flex items-center text-base">
                <span className="material-icons mr-2 text-primary-500">message</span>
                الرسائل النصية
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              {/* Filters */}
              <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="flex-grow relative">
                  <Input
                    type="text"
                    placeholder="بحث في الرسائل..."
                    className="w-full pr-8 pl-2 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <span className="material-icons absolute right-2 top-2 text-slate-400 text-sm">
                    search
                  </span>
                </div>
                <div className="w-full md:w-48">
                  <Select value={messageType} onValueChange={setMessageType}>
                    <SelectTrigger className="w-full h-9 text-sm bg-slate-50 border border-slate-200 rounded-lg">
                      <SelectValue placeholder="نوع الرسائل" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع الرسائل</SelectItem>
                      <SelectItem value="SMS">SMS</SelectItem>
                      <SelectItem value="WhatsApp">WhatsApp</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Messages Table */}
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>نوع الرسالة</TableHead>
                      <TableHead>المرسل/المستلم</TableHead>
                      <TableHead>المحتوى</TableHead>
                      <TableHead>الوقت</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredMessages.length > 0 ? (
                      filteredMessages.map((message: any) => {
                        const { icon, color } = getMessageTypeIcon(message.messageType);
                        return (
                          <TableRow key={message.id}>
                            <TableCell>
                              <div className="flex items-center">
                                <span className={`material-icons ${color} ml-2`}>
                                  {icon}
                                </span>
                                <span>{message.messageType}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div>
                                <p className="font-medium">
                                  {message.contactName || "غير معروف"}
                                </p>
                                <p className="text-sm text-slate-500">
                                  {message.phoneNumber}
                                </p>
                              </div>
                            </TableCell>
                            <TableCell>
                              <p className="truncate max-w-xs">
                                {message.content.substring(0, 50)}
                                {message.content.length > 50 ? "..." : ""}
                              </p>
                            </TableCell>
                            <TableCell>
                              {formatRelativeTime(message.timestamp)}
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setSelectedMessage(message)}
                              >
                                <span className="material-icons">visibility</span>
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    ) : (
                      <TableRow>
                        <TableCell
                          colSpan={5}
                          className="text-center py-6 text-slate-500"
                        >
                          لا توجد رسائل مطابقة للبحث
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Message Details Dialog */}
              {selectedMessage && (
                <Dialog
                  open={!!selectedMessage}
                  onOpenChange={(open) => {
                    if (!open) setSelectedMessage(null);
                  }}
                >
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>تفاصيل الرسالة</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 mt-4">
                      <div className="flex justify-between">
                        <div>
                          <p className="text-sm text-slate-500">من/إلى:</p>
                          <p className="font-medium">
                            {selectedMessage.contactName || "غير معروف"}
                          </p>
                          <p className="text-sm text-slate-500">
                            {selectedMessage.phoneNumber}
                          </p>
                        </div>
                        <div className="text-left">
                          <p className="text-sm text-slate-500">الوقت:</p>
                          <p className="font-medium">
                            {formatRelativeTime(selectedMessage.timestamp)}
                          </p>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-slate-500">نوع الرسالة:</p>
                        <p className="font-medium">{selectedMessage.messageType}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-500">المحتوى:</p>
                        <div className="mt-2 p-3 bg-slate-50 rounded-lg border border-slate-200">
                          <p className="whitespace-pre-wrap">{selectedMessage.content}</p>
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
