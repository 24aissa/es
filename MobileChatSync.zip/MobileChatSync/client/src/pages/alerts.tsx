import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { useChild } from "@/contexts/child-context";
import { formatRelativeTime } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";

export default function Alerts() {
  const { selectedChild } = useChild();
  const [filterType, setFilterType] = useState("all"); // 'all', 'unread', 'read'
  const [severityFilter, setSeverityFilter] = useState("all"); // 'all', 'danger', 'warning', 'info'

  // Fetch all alerts including read ones
  const { data: alerts = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/alerts?includeRead=true`],
    enabled: !!selectedChild?.id,
  });

  // Mark alert as read
  const markAlertAsRead = useMutation({
    mutationFn: async (alertId: number) => {
      return await apiRequest("PATCH", `/api/alerts/${alertId}/read`, undefined);
    },
    onSuccess: () => {
      // Refetch alerts after marking as read
      queryClient.invalidateQueries({
        queryKey: [`/api/children/${selectedChild?.id}/alerts`],
      });
    },
  });

  const handleMarkAlertAsRead = (alertId: number) => {
    markAlertAsRead.mutate(alertId);
  };

  // Filter alerts based on criteria
  const filteredAlerts = alerts.filter((alert: any) => {
    const readFilter =
      filterType === "all" ||
      (filterType === "unread" && !alert.read) ||
      (filterType === "read" && alert.read);

    const severityMatch =
      severityFilter === "all" || alert.severity === severityFilter;

    return readFilter && severityMatch;
  });

  // Helper function to get appropriate icon and background for alert type
  const getAlertStyles = (type: string, severity: string) => {
    let icon = "error";
    let bgClass = "bg-red-50 text-red-700 border-red-200";
    
    if (type === "location") {
      icon = "location_off";
      if (severity === "warning") {
        bgClass = "bg-amber-50 text-amber-700 border-amber-200";
      }
    } else if (type === "app") {
      icon = "download";
      if (severity === "info") {
        bgClass = "bg-blue-50 text-blue-700 border-blue-200";
      }
    } else if (type === "browsing") {
      icon = "public";
      if (severity === "danger") {
        bgClass = "bg-red-50 text-red-700 border-red-200";
      }
    }

    return { icon, bgClass };
  };

  // Get severity badge
  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case "danger":
        return <Badge variant="destructive">خطر</Badge>;
      case "warning":
        return <Badge className="bg-amber-500">تحذير</Badge>;
      case "info":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">معلومات</Badge>;
      default:
        return <Badge variant="secondary">غير معروف</Badge>;
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />

      <main className="flex-1 md:mr-64 min-h-screen">
        <Header title="التنبيهات" subtitle="متابعة ومراقبة جميع التنبيهات المتعلقة بنشاط طفلك" />

        <div className="p-4 md:p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Alerts list */}
            <div className="lg:col-span-2">
              <Card className="shadow-sm">
                <CardHeader className="py-4 px-4 border-b border-slate-100">
                  <CardTitle className="font-semibold flex items-center text-base">
                    <span className="material-icons mr-2 text-primary-500">notifications</span>
                    قائمة التنبيهات
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  {/* Filters */}
                  <div className="flex flex-col md:flex-row gap-4 mb-6">
                    <div className="w-full md:w-48">
                      <Select value={filterType} onValueChange={setFilterType}>
                        <SelectTrigger className="w-full h-9 text-sm bg-slate-50 border border-slate-200 rounded-lg">
                          <SelectValue placeholder="حالة التنبيه" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">جميع التنبيهات</SelectItem>
                          <SelectItem value="unread">غير مقروءة</SelectItem>
                          <SelectItem value="read">مقروءة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="w-full md:w-48">
                      <Select value={severityFilter} onValueChange={setSeverityFilter}>
                        <SelectTrigger className="w-full h-9 text-sm bg-slate-50 border border-slate-200 rounded-lg">
                          <SelectValue placeholder="مستوى الخطورة" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">الكل</SelectItem>
                          <SelectItem value="danger">خطر</SelectItem>
                          <SelectItem value="warning">تحذير</SelectItem>
                          <SelectItem value="info">معلومات</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Alerts Table */}
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>النوع</TableHead>
                          <TableHead>الرسالة</TableHead>
                          <TableHead>الخطورة</TableHead>
                          <TableHead>الوقت</TableHead>
                          <TableHead>الحالة</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredAlerts.length > 0 ? (
                          filteredAlerts.map((alert: any) => {
                            const { icon, bgClass } = getAlertStyles(alert.type, alert.severity);
                            return (
                              <TableRow key={alert.id} className={alert.read ? "bg-slate-50" : ""}>
                                <TableCell>
                                  <div className="flex items-center">
                                    <span className={`material-icons ml-2`}>
                                      {icon}
                                    </span>
                                    <span>{alert.type}</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div>
                                    <p className="font-medium">{alert.message}</p>
                                    <p className="text-sm text-slate-500">
                                      {typeof alert.details === "object"
                                        ? Object.values(alert.details)[0]
                                        : alert.details}
                                    </p>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  {getSeverityBadge(alert.severity)}
                                </TableCell>
                                <TableCell>
                                  {formatRelativeTime(alert.timestamp)}
                                </TableCell>
                                <TableCell>
                                  {alert.read ? (
                                    <Badge variant="outline" className="bg-slate-100 text-slate-700">
                                      مقروءة
                                    </Badge>
                                  ) : (
                                    <Button
                                      size="sm"
                                      onClick={() => handleMarkAlertAsRead(alert.id)}
                                    >
                                      تحديد كمقروءة
                                    </Button>
                                  )}
                                </TableCell>
                              </TableRow>
                            );
                          })
                        ) : (
                          <TableRow>
                            <TableCell
                              colSpan={5}
                              className="text-center py-6 text-slate-500"
                            >
                              لا توجد تنبيهات مطابقة للتصفية
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Alert Settings */}
            <div className="space-y-6">
              <Card className="shadow-sm">
                <CardHeader className="py-4 px-4 border-b border-slate-100">
                  <CardTitle className="font-semibold flex items-center text-base">
                    <span className="material-icons mr-2 text-primary-500">settings</span>
                    إعدادات التنبيهات
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="space-y-4">
                    <h3 className="text-sm font-medium text-slate-700 mb-2">
                      أنواع التنبيهات
                    </h3>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="material-icons text-primary-500 ml-2">location_on</span>
                        <span className="text-sm">مغادرة المناطق الآمنة</span>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="material-icons text-primary-500 ml-2">schedule</span>
                        <span className="text-sm">استخدام الجهاز خارج الأوقات المسموحة</span>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="material-icons text-primary-500 ml-2">public</span>
                        <span className="text-sm">زيارة مواقع غير مناسبة</span>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="material-icons text-primary-500 ml-2">apps</span>
                        <span className="text-sm">تثبيت تطبيقات جديدة</span>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="material-icons text-primary-500 ml-2">battery_alert</span>
                        <span className="text-sm">البطارية منخفضة</span>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="material-icons text-primary-500 ml-2">phone_locked</span>
                        <span className="text-sm">محاولة الوصول لمحتوى مقيد</span>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>

                  <div className="mt-6">
                    <h3 className="text-sm font-medium text-slate-700 mb-2">
                      طرق الإشعار
                    </h3>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">إشعارات التطبيق</span>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm">رسائل البريد الإلكتروني</span>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm">رسائل SMS</span>
                        <Switch />
                      </div>
                    </div>
                  </div>

                  <div className="mt-6">
                    <Button className="w-full">
                      حفظ الإعدادات
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm">
                <CardHeader className="py-4 px-4 border-b border-slate-100">
                  <CardTitle className="font-semibold flex items-center text-base">
                    <span className="material-icons mr-2 text-primary-500">info</span>
                    إحصائيات التنبيهات
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="shadow-sm">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-slate-500">تنبيهات اليوم</p>
                        <p className="text-2xl font-bold text-primary-600 mt-1">
                          {alerts.filter((alert: any) => {
                            const today = new Date();
                            today.setHours(0, 0, 0, 0);
                            return new Date(alert.timestamp) >= today;
                          }).length}
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="shadow-sm">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-slate-500">غير مقروءة</p>
                        <p className="text-2xl font-bold text-primary-600 mt-1">
                          {alerts.filter((alert: any) => !alert.read).length}
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="shadow-sm">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-slate-500">عالية الخطورة</p>
                        <p className="text-2xl font-bold text-red-600 mt-1">
                          {alerts.filter((alert: any) => alert.severity === "danger").length}
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="shadow-sm">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-slate-500">إجمالي</p>
                        <p className="text-2xl font-bold text-primary-600 mt-1">
                          {alerts.length}
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
