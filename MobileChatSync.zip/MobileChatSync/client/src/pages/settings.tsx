import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { useChild } from "@/contexts/child-context";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Settings() {
  const { selectedChild } = useChild();
  const [activeTab, setActiveTab] = useState("general");

  // Fetch child details
  const { data: child } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}`],
    enabled: !!selectedChild?.id,
  });

  // Fetch screen time limit
  const { data: screenTimeLimit } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/screen-time-limit`],
    enabled: !!selectedChild?.id,
  });

  // Update child mutation
  const updateChild = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("PATCH", `/api/children/${selectedChild?.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [`/api/children/${selectedChild?.id}`],
      });
    },
  });

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />

      <main className="flex-1 md:mr-64 min-h-screen">
        <Header title="الإعدادات" subtitle="تخصيص إعدادات المراقبة الأبوية" />

        <div className="p-4 md:p-6">
          <Tabs defaultValue="general" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6 grid grid-cols-4 lg:w-[600px]">
              <TabsTrigger value="general">عام</TabsTrigger>
              <TabsTrigger value="privacy">الخصوصية</TabsTrigger>
              <TabsTrigger value="restrictions">القيود</TabsTrigger>
              <TabsTrigger value="account">الحساب</TabsTrigger>
            </TabsList>

            {/* General Settings Tab */}
            <TabsContent value="general">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="shadow-sm">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">person</span>
                      معلومات الطفل
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    {child && (
                      <div className="space-y-4">
                        <div className="flex justify-center mb-4">
                          <div className="relative">
                            <img
                              src={child.profileImage || "https://images.unsplash.com/photo-1499952127939-9bbf5af6c51c"}
                              alt={`صورة ${child.name}`}
                              className="w-24 h-24 rounded-full border-4 border-primary-100 object-cover"
                            />
                            <Button
                              size="sm"
                              className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 p-0"
                            >
                              <span className="material-icons text-sm">edit</span>
                            </Button>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="child-name">اسم الطفل</Label>
                          <Input
                            id="child-name"
                            defaultValue={child.name}
                            className="bg-slate-50"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="device-info">معلومات الجهاز</Label>
                          <Input
                            id="device-info"
                            defaultValue={child.deviceInfo}
                            disabled
                            className="bg-slate-50"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="device-id">معرف الجهاز</Label>
                          <Input
                            id="device-id"
                            defaultValue={child.deviceId}
                            disabled
                            className="bg-slate-50"
                          />
                        </div>

                        <Button
                          onClick={() => updateChild.mutate({ name: (document.getElementById("child-name") as HTMLInputElement).value })}
                          className="w-full"
                        >
                          حفظ التغييرات
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="shadow-sm">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">notifications</span>
                      إعدادات الإشعارات
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <span className="material-icons text-primary-500 ml-2">warning</span>
                          <span className="text-sm">تنبيهات عالية الخطورة</span>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <span className="material-icons text-primary-500 ml-2">psychology</span>
                          <span className="text-sm">تنبيهات سلوكية</span>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <span className="material-icons text-primary-500 ml-2">update</span>
                          <span className="text-sm">ملخصات يومية</span>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <span className="material-icons text-primary-500 ml-2">email</span>
                          <span className="text-sm">إرسال التنبيهات بالبريد الإلكتروني</span>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <span className="material-icons text-primary-500 ml-2">sms</span>
                          <span className="text-sm">إرسال التنبيهات برسائل SMS</span>
                        </div>
                        <Switch />
                      </div>

                      <Separator className="my-4" />

                      <div className="space-y-2">
                        <Label htmlFor="notification-email">البريد الإلكتروني للتنبيهات</Label>
                        <Input
                          id="notification-email"
                          defaultValue="ahmed@example.com"
                          className="bg-slate-50"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="notification-phone">رقم الهاتف للتنبيهات</Label>
                        <Input
                          id="notification-phone"
                          defaultValue="+971501234567"
                          className="bg-slate-50"
                        />
                      </div>

                      <Button className="w-full">
                        حفظ إعدادات التنبيهات
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-sm lg:col-span-2">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">backup</span>
                      النسخ الاحتياطي والمزامنة
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="border rounded-lg p-4">
                        <h3 className="font-medium flex items-center mb-2">
                          <span className="material-icons text-primary-500 ml-2">schedule</span>
                          النسخ الاحتياطي التلقائي
                        </h3>
                        <p className="text-sm text-slate-500 mb-4">
                          نسخ احتياطي تلقائي لجميع بيانات المراقبة في السحابة
                        </p>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">تفعيل النسخ الاحتياطي</span>
                          <Switch defaultChecked />
                        </div>
                      </div>

                      <div className="border rounded-lg p-4">
                        <h3 className="font-medium flex items-center mb-2">
                          <span className="material-icons text-primary-500 ml-2">cloud_sync</span>
                          مزامنة متعددة الأجهزة
                        </h3>
                        <p className="text-sm text-slate-500 mb-4">
                          مزامنة الإعدادات والتقارير بين جميع أجهزتك
                        </p>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">تفعيل المزامنة</span>
                          <Switch defaultChecked />
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 flex gap-4">
                      <Button variant="outline" className="flex-1">
                        <span className="material-icons ml-1 text-sm">backup</span>
                        نسخ احتياطي الآن
                      </Button>
                      <Button variant="outline" className="flex-1">
                        <span className="material-icons ml-1 text-sm">settings_backup_restore</span>
                        استعادة من نسخة احتياطية
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Privacy Settings Tab */}
            <TabsContent value="privacy">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="shadow-sm">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">privacy_tip</span>
                      خصوصية جمع البيانات
                    </CardTitle>
                    <CardDescription>
                      تحديد البيانات التي ترغب في مراقبتها من جهاز طفلك
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">تتبع الموقع</h3>
                          <p className="text-xs text-slate-500">تتبع موقع طفلك في الوقت الفعلي</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">سجل المكالمات</h3>
                          <p className="text-xs text-slate-500">مراقبة المكالمات الواردة والصادرة</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">محتوى الرسائل</h3>
                          <p className="text-xs text-slate-500">الاطلاع على محتوى الرسائل النصية</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">نشاط التطبيقات</h3>
                          <p className="text-xs text-slate-500">مراقبة التطبيقات المثبتة والمستخدمة</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">سجل التصفح</h3>
                          <p className="text-xs text-slate-500">مراقبة المواقع التي تمت زيارتها</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">التقاط لقطات شاشة</h3>
                          <p className="text-xs text-slate-500">التقاط لقطات عشوائية من شاشة الجهاز</p>
                        </div>
                        <Switch />
                      </div>

                      <div className="p-3 bg-amber-50 rounded-lg border border-amber-100 text-sm text-amber-700 mt-4">
                        <p className="flex items-start">
                          <span className="material-icons text-amber-500 ml-2 mt-0.5 text-base">info</span>
                          <span>تأكد من إعلام طفلك بالمراقبة بطريقة مناسبة لعمره لبناء الثقة والحفاظ على العلاقة الأسرية.</span>
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-sm">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">visibility</span>
                      وضع الظهور
                    </CardTitle>
                    <CardDescription>
                      تحديد ما إذا كان طفلك يعلم بوجود المراقبة
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">وضع التخفي</h3>
                          <p className="text-xs text-slate-500">إخفاء التطبيق على جهاز الطفل</p>
                        </div>
                        <Switch />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">إشعارات للطفل</h3>
                          <p className="text-xs text-slate-500">عرض إشعارات للطفل عند مراقبة النشاط</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">رمز التطبيق</h3>
                          <p className="text-xs text-slate-500">إظهار رمز التطبيق في قائمة التطبيقات</p>
                        </div>
                        <Switch defaultChecked />
                      </div>

                      <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                        <h3 className="text-sm font-medium mb-2">رسالة للطفل</h3>
                        <p className="text-xs text-slate-500 mb-2">
                          ستظهر هذه الرسالة للطفل إذا كان وضع الإشعارات مفعل
                        </p>
                        <Input
                          defaultValue="أنت محمي! نقوم بمراقبة نشاطك للحفاظ على سلامتك."
                          className="bg-white"
                        />
                      </div>

                      <div className="p-3 bg-blue-50 rounded-lg border border-blue-100 text-sm text-blue-700 mt-4">
                        <p className="flex items-start">
                          <span className="material-icons text-blue-500 ml-2 mt-0.5 text-base">psychology</span>
                          <span>ننصح بالشفافية مع الأطفال حول المراقبة، خاصة مع الأطفال الأكبر سنًا، لبناء علاقة قائمة على الثقة.</span>
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-sm lg:col-span-2">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">data_usage</span>
                      استخدام البيانات
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">حفظ البيانات</h3>
                          <p className="text-xs text-slate-500">مدة الاحتفاظ بالبيانات التاريخية</p>
                        </div>
                        <Select defaultValue="90">
                          <SelectTrigger className="w-28">
                            <SelectValue placeholder="اختر المدة" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="30">30 يوم</SelectItem>
                            <SelectItem value="60">60 يوم</SelectItem>
                            <SelectItem value="90">90 يوم</SelectItem>
                            <SelectItem value="180">6 أشهر</SelectItem>
                            <SelectItem value="365">سنة</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">حفظ التقارير</h3>
                          <p className="text-xs text-slate-500">استخراج تقارير دورية وحفظها</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">مشاركة البيانات المجهولة</h3>
                          <p className="text-xs text-slate-500">المساهمة في تحسين الخدمة</p>
                        </div>
                        <Switch />
                      </div>

                      <div className="mt-4">
                        <Button variant="outline" className="w-full">
                          <span className="material-icons ml-1 text-sm">delete</span>
                          حذف جميع البيانات
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Restrictions Tab */}
            <TabsContent value="restrictions">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="shadow-sm">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">timer</span>
                      وقت الاستخدام
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="daily-limit">الحد اليومي (بالدقائق)</Label>
                        <Input
                          id="daily-limit"
                          type="number"
                          defaultValue={screenTimeLimit?.dailyLimit || 360}
                          className="bg-slate-50"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>أيام مختلفة</Label>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">حدود مختلفة في عطلة نهاية الأسبوع</span>
                          <Switch defaultChecked />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="weekday-limit">أيام الدراسة (دقائق)</Label>
                          <Input
                            id="weekday-limit"
                            type="number"
                            defaultValue={300}
                            className="bg-slate-50"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="weekend-limit">عطلة نهاية الأسبوع (دقائق)</Label>
                          <Input
                            id="weekend-limit"
                            type="number"
                            defaultValue={480}
                            className="bg-slate-50"
                          />
                        </div>
                      </div>

                      <Separator className="my-4" />

                      <div className="space-y-2">
                        <Label>وقت النوم</Label>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">تقييد الاستخدام في وقت النوم</span>
                          <Switch defaultChecked />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="bedtime-start">من الساعة</Label>
                          <Input
                            id="bedtime-start"
                            type="time"
                            defaultValue="22:00"
                            className="bg-slate-50"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="bedtime-end">إلى الساعة</Label>
                          <Input
                            id="bedtime-end"
                            type="time"
                            defaultValue="07:00"
                            className="bg-slate-50"
                          />
                        </div>
                      </div>

                      <Button className="w-full">
                        حفظ إعدادات وقت الاستخدام
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-sm">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">block</span>
                      قيود المحتوى
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">فلترة المحتوى غير المناسب</h3>
                          <p className="text-xs text-slate-500">حظر المواقع والمحتوى غير المناسب للعمر</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">حظر التطبيقات حسب التصنيف العمري</h3>
                          <p className="text-xs text-slate-500">منع التطبيقات غير المناسبة لعمر الطفل</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">وضع البحث الآمن</h3>
                          <p className="text-xs text-slate-500">تفعيل البحث الآمن في جوجل وغيره</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium">وضع القائمة البيضاء</h3>
                          <p className="text-xs text-slate-500">السماح فقط بالمواقع والتطبيقات المصرح بها</p>
                        </div>
                        <Switch />
                      </div>

                      <Separator className="my-4" />

                      <div className="space-y-2">
                        <Label>تصنيف العمر المناسب</Label>
                        <Select defaultValue="9-12">
                          <SelectTrigger className="w-full bg-slate-50">
                            <SelectValue placeholder="اختر الفئة العمرية" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="4-8">4-8 سنوات</SelectItem>
                            <SelectItem value="9-12">9-12 سنة</SelectItem>
                            <SelectItem value="13-15">13-15 سنة</SelectItem>
                            <SelectItem value="16-17">16-17 سنة</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <Button className="w-full">
                        حفظ إعدادات القيود
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-sm lg:col-span-2">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">gpp_good</span>
                      إعدادات الأمان
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="text-sm font-medium">قفل الإعدادات</h3>
                        <div className="space-y-2">
                          <Label htmlFor="pin-code">رمز الحماية (PIN)</Label>
                          <Input
                            id="pin-code"
                            type="password"
                            placeholder="أدخل رمز الحماية"
                            className="bg-slate-50"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="confirm-pin">تأكيد رمز الحماية</Label>
                          <Input
                            id="confirm-pin"
                            type="password"
                            placeholder="أعد إدخال رمز الحماية"
                            className="bg-slate-50"
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <span className="text-sm">قفل إعدادات التطبيق برمز حماية</span>
                          <Switch defaultChecked />
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-sm font-medium">إجراءات الطوارئ</h3>
                        
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="text-sm font-medium">زر طوارئ للطفل</h3>
                            <p className="text-xs text-slate-500">تمكين الطفل من إرسال تنبيه طوارئ</p>
                          </div>
                          <Switch defaultChecked />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="text-sm font-medium">تتبع دقيق في حالات الطوارئ</h3>
                            <p className="text-xs text-slate-500">زيادة دقة التتبع عند الضغط على زر الطوارئ</p>
                          </div>
                          <Switch defaultChecked />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="emergency-contacts">جهات اتصال الطوارئ</Label>
                          <Input
                            id="emergency-contacts"
                            placeholder="أدخل أرقام الطوارئ مفصولة بفواصل"
                            defaultValue="+971501234567, +971507654321"
                            className="bg-slate-50"
                          />
                        </div>
                      </div>
                    </div>

                    <Button className="w-full mt-6">
                      حفظ إعدادات الأمان
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Account Tab */}
            <TabsContent value="account">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="shadow-sm">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">account_circle</span>
                      معلومات الحساب
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="parent-name">الاسم</Label>
                        <Input
                          id="parent-name"
                          defaultValue="أحمد محمد"
                          className="bg-slate-50"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="parent-email">البريد الإلكتروني</Label>
                        <Input
                          id="parent-email"
                          defaultValue="ahmed@example.com"
                          className="bg-slate-50"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="parent-phone">رقم الهاتف</Label>
                        <Input
                          id="parent-phone"
                          defaultValue="+971501234567"
                          className="bg-slate-50"
                        />
                      </div>

                      <Button className="w-full">
                        تحديث معلومات الحساب
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-sm">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">lock</span>
                      تغيير كلمة المرور
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="current-password">كلمة المرور الحالية</Label>
                        <Input
                          id="current-password"
                          type="password"
                          placeholder="أدخل كلمة المرور الحالية"
                          className="bg-slate-50"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="new-password">كلمة المرور الجديدة</Label>
                        <Input
                          id="new-password"
                          type="password"
                          placeholder="أدخل كلمة المرور الجديدة"
                          className="bg-slate-50"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="confirm-password">تأكيد كلمة المرور</Label>
                        <Input
                          id="confirm-password"
                          type="password"
                          placeholder="أعد إدخال كلمة المرور الجديدة"
                          className="bg-slate-50"
                        />
                      </div>

                      <Button className="w-full">
                        تغيير كلمة المرور
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-sm">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-primary-500">devices</span>
                      الأجهزة المرتبطة
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="border rounded-lg p-4 flex justify-between items-center">
                        <div className="flex items-center">
                          <span className="material-icons text-primary-500 ml-3">smartphone</span>
                          <div>
                            <p className="text-sm font-medium">هاتف سارة (Samsung Galaxy S21)</p>
                            <p className="text-xs text-slate-500">آخر اتصال: منذ 5 دقائق</p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="h-8">
                          إزالة
                        </Button>
                      </div>
                      
                      <div className="border rounded-lg p-4 flex justify-between items-center">
                        <div className="flex items-center">
                          <span className="material-icons text-primary-500 ml-3">phone_iphone</span>
                          <div>
                            <p className="text-sm font-medium">هاتف عمر (iPhone 13)</p>
                            <p className="text-xs text-slate-500">آخر اتصال: منذ ساعتين</p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="h-8">
                          إزالة
                        </Button>
                      </div>

                      <Button className="w-full">
                        <span className="material-icons ml-1 text-sm">add</span>
                        إضافة جهاز جديد
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-sm">
                  <CardHeader className="py-4 px-4 border-b border-slate-100">
                    <CardTitle className="font-semibold flex items-center text-base">
                      <span className="material-icons mr-2 text-red-500">warning</span>
                      إجراءات الحساب
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <Button variant="outline" className="w-full">
                        <span className="material-icons ml-1 text-sm">sync</span>
                        إعادة تعيين الإعدادات الافتراضية
                      </Button>
                      
                      <Button variant="outline" className="w-full">
                        <span className="material-icons ml-1 text-sm">delete</span>
                        حذف جميع البيانات
                      </Button>
                      
                      <Button variant="destructive" className="w-full">
                        <span className="material-icons ml-1 text-sm">delete_forever</span>
                        إغلاق الحساب
                      </Button>

                      <div className="p-3 bg-red-50 rounded-lg border border-red-200 text-sm text-red-700">
                        <p className="flex items-start">
                          <span className="material-icons text-red-500 ml-2 mt-0.5 text-base">info</span>
                          <span>سيؤدي إغلاق الحساب إلى حذف جميع البيانات والإعدادات بشكل نهائي ولا يمكن استرجاعها.</span>
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
