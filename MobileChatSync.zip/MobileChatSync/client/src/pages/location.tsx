import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { useChild } from "@/contexts/child-context";
import { Map } from "@/components/ui/map";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatRelativeTime } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function Location() {
  const { selectedChild } = useChild();
  const [newSafeZoneName, setNewSafeZoneName] = useState("");
  const [newSafeZoneRadius, setNewSafeZoneRadius] = useState(200);
  const [newSafeZoneCoords, setNewSafeZoneCoords] = useState<{
    latitude: string;
    longitude: string;
  } | null>(null);
  const [addingZone, setAddingZone] = useState(false);

  // Fetch locations
  const { data: locations = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/locations?limit=20`],
    enabled: !!selectedChild?.id,
  });

  // Fetch safe zones
  const { data: safeZones = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/safe-zones`],
    enabled: !!selectedChild?.id,
  });

  // Add a new safe zone
  const addSafeZone = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/safe-zones", data);
    },
    onSuccess: () => {
      // Refetch safe zones after adding a new one
      queryClient.invalidateQueries({
        queryKey: [`/api/children/${selectedChild?.id}/safe-zones`],
      });
      setNewSafeZoneName("");
      setNewSafeZoneRadius(200);
      setNewSafeZoneCoords(null);
      setAddingZone(false);
    },
  });

  // Delete a safe zone
  const deleteSafeZone = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/safe-zones/${id}`, undefined);
    },
    onSuccess: () => {
      // Refetch safe zones after deletion
      queryClient.invalidateQueries({
        queryKey: [`/api/children/${selectedChild?.id}/safe-zones`],
      });
    },
  });

  const handleAddSafeZone = () => {
    if (!selectedChild || !newSafeZoneCoords || !newSafeZoneName) return;

    addSafeZone.mutate({
      childId: selectedChild.id,
      name: newSafeZoneName,
      latitude: newSafeZoneCoords.latitude,
      longitude: newSafeZoneCoords.longitude,
      radius: newSafeZoneRadius,
      active: true,
    });
  };

  const handleDeleteSafeZone = (id: number) => {
    deleteSafeZone.mutate(id);
  };

  const handleMapClick = (lat: number, lng: number) => {
    if (addingZone) {
      setNewSafeZoneCoords({
        latitude: lat.toString(),
        longitude: lng.toString(),
      });
    }
  };

  // Get the latest location
  const latestLocation = locations[0];

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />

      <main className="flex-1 md:mr-64 min-h-screen">
        <Header title="تتبع الموقع" subtitle="تتبع موقع طفلك وإدارة المناطق الآمنة" />

        <div className="p-4 md:p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Map */}
            <div className="lg:col-span-2">
              <Card className="shadow-sm">
                <CardHeader className="py-4 px-4 border-b border-slate-100">
                  <CardTitle className="font-semibold flex items-center text-base">
                    <span className="material-icons mr-2 text-primary-500">map</span>
                    خريطة الموقع الحالي
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  {latestLocation ? (
                    <Map
                      latitude={latestLocation.latitude}
                      longitude={latestLocation.longitude}
                      markers={[
                        {
                          latitude: latestLocation.latitude,
                          longitude: latestLocation.longitude,
                          tooltip: latestLocation.locationName || "الموقع الحالي",
                          isChild: true,
                        },
                      ]}
                      safeZones={safeZones}
                      onMapClick={handleMapClick}
                      height="500px"
                      className="mb-4"
                    />
                  ) : (
                    <div className="h-[500px] bg-slate-100 relative rounded-lg">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center p-4">
                          <span className="material-icons text-slate-400 text-5xl">map</span>
                          <p className="mt-2 text-slate-500">سيتم عرض الخريطة هنا</p>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar with Location History and Safe Zones */}
            <div className="space-y-6">
              {/* Location History */}
              <Card className="shadow-sm">
                <CardHeader className="py-4 px-4 border-b border-slate-100">
                  <CardTitle className="font-semibold flex items-center text-base">
                    <span className="material-icons mr-2 text-primary-500">history</span>
                    سجل المواقع
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="space-y-3 max-h-96 overflow-y-auto scrollbar-thin">
                    {locations.map((location: any, index: number) => (
                      <div
                        key={location.id}
                        className={`flex items-center text-sm ${
                          index === 0
                            ? "border-r-2 border-primary-500 pr-3"
                            : "border-r-2 border-slate-300 pr-3"
                        }`}
                      >
                        <span
                          className={`material-icons ml-2 text-lg ${
                            index === 0 ? "text-primary-500" : "text-slate-400"
                          }`}
                        >
                          location_on
                        </span>
                        <div className="flex-grow">
                          <p className="font-medium">{location.locationName || "موقع غير معروف"}</p>
                          <p className="text-slate-500 text-xs">
                            {formatRelativeTime(location.timestamp)}
                          </p>
                        </div>
                      </div>
                    ))}

                    {locations.length === 0 && (
                      <div className="text-center py-4 text-slate-500">
                        لا يوجد سجل مواقع
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Safe Zones */}
              <Card className="shadow-sm">
                <CardHeader className="py-4 px-4 border-b border-slate-100">
                  <CardTitle className="font-semibold flex items-center text-base">
                    <span className="material-icons mr-2 text-secondary-500">fence</span>
                    المناطق الآمنة
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="flex flex-wrap gap-2 mb-4">
                    {safeZones.map((zone: any) => (
                      <Badge
                        key={zone.id}
                        variant="outline"
                        className="bg-white flex items-center border-slate-200 px-3 py-1 rounded-full text-sm"
                      >
                        {zone.name}
                        <button
                          className="material-icons text-slate-400 hover:text-red-500 mr-1 text-xs"
                          onClick={() => handleDeleteSafeZone(zone.id)}
                        >
                          close
                        </button>
                      </Badge>
                    ))}

                    {safeZones.length === 0 && (
                      <p className="text-slate-500 text-sm">
                        لم يتم إضافة مناطق آمنة بعد
                      </p>
                    )}
                  </div>

                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="w-full">
                        <span className="material-icons mr-1 text-sm">add</span>
                        إضافة منطقة آمنة جديدة
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>إضافة منطقة آمنة جديدة</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="safezone-name">اسم المنطقة</Label>
                          <Input
                            id="safezone-name"
                            value={newSafeZoneName}
                            onChange={(e) => setNewSafeZoneName(e.target.value)}
                            placeholder="مثال: المنزل، المدرسة"
                          />
                        </div>
                        <div>
                          <Label htmlFor="safezone-radius">نصف القطر (متر)</Label>
                          <Input
                            id="safezone-radius"
                            type="number"
                            value={newSafeZoneRadius}
                            onChange={(e) => setNewSafeZoneRadius(Number(e.target.value))}
                            min={50}
                            max={1000}
                          />
                        </div>
                        <div>
                          <Label>الموقع</Label>
                          <p className="text-sm text-slate-500 mb-2">
                            {addingZone
                              ? "انقر على الخريطة لتحديد الموقع"
                              : "اضغط على زر تحديد الموقع"}
                          </p>
                          <Button
                            variant="outline"
                            type="button"
                            onClick={() => setAddingZone(!addingZone)}
                          >
                            {addingZone ? "إلغاء" : "تحديد الموقع على الخريطة"}
                          </Button>
                          {newSafeZoneCoords && (
                            <p className="mt-2 text-sm text-green-600">
                              تم اختيار الموقع بنجاح!
                            </p>
                          )}
                        </div>
                        <div className="flex justify-end gap-2 mt-4">
                          <Button
                            variant="outline"
                            onClick={() => {
                              setAddingZone(false);
                              setNewSafeZoneCoords(null);
                            }}
                          >
                            إلغاء
                          </Button>
                          <Button
                            onClick={handleAddSafeZone}
                            disabled={!newSafeZoneName || !newSafeZoneCoords}
                          >
                            إضافة
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-100 text-sm text-blue-700">
                    <p className="flex items-center">
                      <span className="material-icons text-blue-500 ml-2 text-base">info</span>
                      ستتلقى تنبيهًا عندما يخرج طفلك من المنطقة الآمنة أو يدخل إليها
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
