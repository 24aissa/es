import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { useChild } from "@/contexts/child-context";
import { formatRelativeTime } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function Browsing() {
  const { selectedChild } = useChild();
  const [searchQuery, setSearchQuery] = useState("");
  const [timeFilter, setTimeFilter] = useState("all"); // 'all', 'today', 'week', 'month'

  // Fetch browsing history with a larger limit for this dedicated page
  const { data: browsing = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/browsing?limit=100`],
    enabled: !!selectedChild?.id,
  });

  // Filter browsing history based on search query and time filter
  const filteredBrowsing = browsing.filter((item: any) => {
    const searchMatch =
      searchQuery === "" ||
      (item.title && item.title.toLowerCase().includes(searchQuery.toLowerCase())) ||
      item.url.toLowerCase().includes(searchQuery.toLowerCase());

    let timeMatch = true;
    if (timeFilter !== "all") {
      const now = new Date();
      const itemDate = new Date(item.timestamp);
      
      if (timeFilter === "today") {
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        timeMatch = itemDate >= today;
      } else if (timeFilter === "week") {
        const weekAgo = new Date(now);
        weekAgo.setDate(now.getDate() - 7);
        timeMatch = itemDate >= weekAgo;
      } else if (timeFilter === "month") {
        const monthAgo = new Date(now);
        monthAgo.setMonth(now.getMonth() - 1);
        timeMatch = itemDate >= monthAgo;
      }
    }

    return searchMatch && timeMatch;
  });

  // Extract domain from URL
  const getDomain = (url: string) => {
    try {
      const domain = new URL(url).hostname;
      return domain.replace(/^www\./, "");
    } catch (error) {
      return url;
    }
  };

  // Get icon for domain
  const getDomainIcon = (url: string) => {
    const domain = getDomain(url).toLowerCase();
    
    if (domain.includes("google")) return "search";
    if (domain.includes("youtube")) return "smart_display";
    if (domain.includes("facebook")) return "thumb_up";
    if (domain.includes("instagram")) return "photo";
    if (domain.includes("twitter") || domain.includes("x.com")) return "trending_up";
    if (domain.includes("tiktok")) return "videocam";
    if (domain.includes("snapchat")) return "visibility";
    if (domain.includes("wikipedia")) return "book";
    if (domain.includes("amazon")) return "shopping_cart";
    if (domain.includes("netflix")) return "movie";
    if (domain.includes("spotify")) return "music_note";
    
    // Default
    return "public";
  };

  // Check if a domain might be inappropriate (simplified demo implementation)
  const isInappropriateDomain = (url: string) => {
    const domain = getDomain(url).toLowerCase();
    
    // This is a simplified check - in a real app, you'd use a more comprehensive database or service
    const inappropriateKeywords = [
      "adult", "xxx", "sex", "porn", "gambling", "bet", "casino", "violence", "weapon", "drug"
    ];
    
    return inappropriateKeywords.some(keyword => domain.includes(keyword));
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />

      <main className="flex-1 md:mr-64 min-h-screen">
        <Header title="سجل التصفح" subtitle="متابعة نشاط تصفح الإنترنت لطفلك" />

        <div className="p-4 md:p-6">
          <Card className="shadow-sm">
            <CardHeader className="py-4 px-4 border-b border-slate-100">
              <CardTitle className="font-semibold flex items-center text-base">
                <span className="material-icons mr-2 text-primary-500">public</span>
                سجل التصفح
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              {/* Filters */}
              <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="flex-grow relative">
                  <Input
                    type="text"
                    placeholder="بحث في سجل التصفح..."
                    className="w-full pr-8 pl-2 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <span className="material-icons absolute right-2 top-2 text-slate-400 text-sm">
                    search
                  </span>
                </div>
                <div className="w-full md:w-48">
                  <Select value={timeFilter} onValueChange={setTimeFilter}>
                    <SelectTrigger className="w-full h-9 text-sm bg-slate-50 border border-slate-200 rounded-lg">
                      <SelectValue placeholder="الفترة الزمنية" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">كل الوقت</SelectItem>
                      <SelectItem value="today">اليوم</SelectItem>
                      <SelectItem value="week">آخر أسبوع</SelectItem>
                      <SelectItem value="month">آخر شهر</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Browsing History Table */}
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>الموقع</TableHead>
                      <TableHead>العنوان</TableHead>
                      <TableHead>الوقت</TableHead>
                      <TableHead>تقييم</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBrowsing.length > 0 ? (
                      filteredBrowsing.map((item: any) => {
                        const domain = getDomain(item.url);
                        const isInappropriate = isInappropriateDomain(item.url);
                        return (
                          <TableRow key={item.id}>
                            <TableCell>
                              <div className="flex items-center">
                                <span className="material-icons text-primary-500 ml-2">
                                  {getDomainIcon(item.url)}
                                </span>
                                <span>{domain}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="truncate max-w-xs">
                                {item.title || "بدون عنوان"}
                              </div>
                            </TableCell>
                            <TableCell>
                              {formatRelativeTime(item.timestamp)}
                            </TableCell>
                            <TableCell>
                              {isInappropriate ? (
                                <Badge variant="destructive">محتوى غير مناسب</Badge>
                              ) : (
                                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                  مناسب
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0"
                              >
                                <span className="material-icons">more_vert</span>
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    ) : (
                      <TableRow>
                        <TableCell
                          colSpan={5}
                          className="text-center py-6 text-slate-500"
                        >
                          لا يوجد سجل تصفح مطابق للبحث
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Additional Section: Safe Browsing */}
          <div className="mt-6">
            <Card className="shadow-sm">
              <CardHeader className="py-4 px-4 border-b border-slate-100">
                <CardTitle className="font-semibold flex items-center text-base">
                  <span className="material-icons mr-2 text-green-500">security</span>
                  تصفح آمن
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-start">
                        <span className="material-icons text-primary-500 ml-3 mt-1">block</span>
                        <div>
                          <h3 className="font-medium">حظر المواقع غير المناسبة</h3>
                          <p className="text-sm text-slate-500 mt-1">
                            فلترة المحتوى غير المناسب للأطفال تلقائيًا
                          </p>
                          <Button variant="link" className="h-auto p-0 mt-2 text-primary-600">
                            تفعيل الآن
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-start">
                        <span className="material-icons text-primary-500 ml-3 mt-1">schedule</span>
                        <div>
                          <h3 className="font-medium">تحديد أوقات التصفح</h3>
                          <p className="text-sm text-slate-500 mt-1">
                            تقييد وقت تصفح الإنترنت حسب جدول محدد
                          </p>
                          <Button variant="link" className="h-auto p-0 mt-2 text-primary-600">
                            إعداد الجدول
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-start">
                        <span className="material-icons text-primary-500 ml-3 mt-1">format_list_bulleted</span>
                        <div>
                          <h3 className="font-medium">القائمة البيضاء</h3>
                          <p className="text-sm text-slate-500 mt-1">
                            السماح فقط بالمواقع المعتمدة والآمنة
                          </p>
                          <Button variant="link" className="h-auto p-0 mt-2 text-primary-600">
                            إدارة القائمة
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
