import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { ChildStatus } from "@/components/dashboard/child-status";
import { LocationTracker } from "@/components/dashboard/location-tracker";
import { ActivityAlerts } from "@/components/dashboard/activity-alerts";
import { ScreenTime } from "@/components/dashboard/screen-time";
import { AppMonitoring } from "@/components/dashboard/app-monitoring";
import { CommunicationLog } from "@/components/dashboard/communication-log";
import { useChild } from "@/contexts/child-context";

export default function Dashboard() {
  const { selectedChild, loading } = useChild();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <svg
            className="animate-spin h-12 w-12 text-primary-500 mx-auto"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            ></circle>
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            ></path>
          </svg>
          <p className="mt-4 text-slate-600">جاري تحميل البيانات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />

      <main className="flex-1 md:mr-64 min-h-screen">
        <Header 
          title="لوحة المعلومات" 
          subtitle={selectedChild ? `مرحبًا، هذا ملخص آخر نشاطات ${selectedChild.name}` : "مرحبًا، هذا ملخص آخر نشاطات طفلك"} 
        />

        <div className="p-4 md:p-6">
          {/* Status overview */}
          {selectedChild && <ChildStatus child={selectedChild} />}

          {/* Main Dashboard Sections */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Map and Location */}
            <div className="lg:col-span-2">
              <LocationTracker />
            </div>

            {/* Recent Activity & Alerts */}
            <ActivityAlerts />
          </div>

          {/* Additional Sections */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
            {/* Screen Time */}
            <ScreenTime />

            {/* App Monitoring */}
            <AppMonitoring />

            {/* Call & Message Log */}
            <CommunicationLog />
          </div>
        </div>
      </main>
    </div>
  );
}
