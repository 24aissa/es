import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { useChild } from "@/contexts/child-context";
import { formatRelativeTime } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScreenTime } from "@/components/dashboard/screen-time";

export default function Apps() {
  const { selectedChild } = useChild();
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");

  // Fetch apps
  const { data: apps = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/apps`],
    enabled: !!selectedChild?.id,
  });

  // Fetch app usage
  const { data: appUsage = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/app-usage`],
    enabled: !!selectedChild?.id,
  });

  // Toggle app blocking
  const toggleAppBlocking = useMutation({
    mutationFn: async ({ appId, isBlocked }: { appId: number; isBlocked: boolean }) => {
      return await apiRequest("PATCH", `/api/apps/${appId}`, { isBlocked });
    },
    onSuccess: () => {
      // Refetch apps after toggling
      queryClient.invalidateQueries({
        queryKey: [`/api/children/${selectedChild?.id}/apps`],
      });
    },
  });

  const handleToggleAppBlocking = (appId: number, isBlocked: boolean) => {
    toggleAppBlocking.mutate({ appId, isBlocked: !isBlocked });
  };

  // Get all unique categories
  const categories = [
    "all",
    ...Array.from(
      new Set(
        apps
          .map((app: any) => app.category)
          .filter((category: string | null) => category)
      )
    ),
  ];

  // Filter apps by search query and category
  const filteredApps = apps.filter((app: any) => {
    const nameMatch = app.name.toLowerCase().includes(searchQuery.toLowerCase());
    const categoryMatch =
      categoryFilter === "all" ||
      (app.category && app.category === categoryFilter);
    return nameMatch && categoryMatch;
  });

  // Get app usage data for an app
  const getAppUsage = (appId: number) => {
    return appUsage.find((usage: any) => usage.appId === appId);
  };

  // Get gradient background color for app icon based on app name
  const getAppGradient = (appName: string) => {
    const gradients = [
      "bg-gradient-to-br from-purple-500 to-pink-500",
      "bg-gradient-to-br from-cyan-500 to-blue-500",
      "bg-gradient-to-br from-red-500 to-orange-500",
      "bg-gradient-to-br from-red-500 to-red-600",
      "bg-gradient-to-br from-green-500 to-emerald-600",
      "bg-gradient-to-br from-yellow-500 to-orange-500",
      "bg-gradient-to-br from-blue-500 to-indigo-600",
    ];

    // Simple hash function to get a consistent gradient for the same app name
    const hash = appName.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return gradients[hash % gradients.length];
  };

  // Get icon for app based on app name/category
  const getAppIcon = (app: any) => {
    if (app.name.toLowerCase().includes("instagram")) return "photo";
    if (app.name.toLowerCase().includes("whatsapp")) return "message";
    if (app.name.toLowerCase().includes("tiktok")) return "videocam";
    if (app.name.toLowerCase().includes("youtube")) return "smart_display";
    if (app.name.toLowerCase().includes("spotify")) return "music_note";
    if (app.name.toLowerCase().includes("facebook")) return "thumb_up";
    if (app.name.toLowerCase().includes("twitter")) return "trending_up";
    if (app.name.toLowerCase().includes("snapchat")) return "visibility";
    if (app.name.toLowerCase().includes("camera")) return "camera_alt";
    if (app.name.toLowerCase().includes("games")) return "sports_esports";
    if (app.name.toLowerCase().includes("maps")) return "map";
    
    // Default icon based on category
    if (app.category?.toLowerCase().includes("تطبيق اجتماعي")) return "people";
    if (app.category?.toLowerCase().includes("فيديو")) return "video_library";
    if (app.category?.toLowerCase().includes("مراسلة")) return "chat";
    if (app.category?.toLowerCase().includes("موسيقى")) return "music_note";
    
    // Fallback
    return "apps";
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />

      <main className="flex-1 md:mr-64 min-h-screen">
        <Header title="التطبيقات المثبتة" subtitle="إدارة تطبيقات طفلك ومراقبة استخدامها" />

        <div className="p-4 md:p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Apps List */}
            <div className="lg:col-span-2">
              <Card className="shadow-sm">
                <CardHeader className="py-4 px-4 border-b border-slate-100">
                  <CardTitle className="font-semibold flex items-center text-base">
                    <span className="material-icons mr-2 text-primary-500">apps</span>
                    التطبيقات المثبتة
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  {/* Search and Filters */}
                  <div className="flex flex-col md:flex-row gap-4 mb-6">
                    <div className="flex-grow relative">
                      <Input
                        type="text"
                        placeholder="بحث في التطبيقات..."
                        className="w-full pr-8 pl-2 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                      <span className="material-icons absolute right-2 top-2 text-slate-400 text-sm">
                        search
                      </span>
                    </div>
                    <div className="w-full md:w-48">
                      <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                        <SelectTrigger className="w-full h-9 text-sm bg-slate-50 border border-slate-200 rounded-lg">
                          <SelectValue placeholder="تصنيف التطبيق" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category: string) => (
                            <SelectItem key={category} value={category}>
                              {category === "all" ? "جميع التصنيفات" : category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Apps Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
                    {filteredApps.length > 0 ? (
                      filteredApps.map((app: any) => {
                        const usage = getAppUsage(app.id);
                        return (
                          <Card key={app.id} className="shadow-sm hover:shadow-md transition-shadow">
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between">
                                <div className="flex items-start gap-3">
                                  <div className={`w-12 h-12 rounded-lg ${getAppGradient(app.name)} flex items-center justify-center`}>
                                    <span className="material-icons text-white text-xl">
                                      {getAppIcon(app)}
                                    </span>
                                  </div>
                                  <div>
                                    <h3 className="font-medium">{app.name}</h3>
                                    <p className="text-xs text-slate-500 mt-1">
                                      {app.category || "تطبيق"}
                                    </p>
                                    <p className="text-xs text-slate-500 mt-1">
                                      تم التثبيت: {formatRelativeTime(app.installDate)}
                                    </p>
                                    {usage && (
                                      <p className="text-xs text-primary-600 mt-1">
                                        وقت الاستخدام اليوم: {Math.floor(usage.duration / 60)} دقيقة
                                      </p>
                                    )}
                                  </div>
                                </div>
                                <div className="flex flex-col items-center">
                                  <Switch
                                    checked={!app.isBlocked}
                                    onCheckedChange={() => handleToggleAppBlocking(app.id, app.isBlocked)}
                                  />
                                  <span className="text-xs text-slate-500 mt-1">
                                    {app.isBlocked ? "محظور" : "مسموح"}
                                  </span>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })
                    ) : (
                      <div className="md:col-span-2 lg:col-span-2 text-center py-10 text-slate-500">
                        لا توجد تطبيقات مطابقة
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar with Screen Time */}
            <div className="space-y-6">
              <ScreenTime />

              <Card className="shadow-sm">
                <CardHeader className="py-4 px-4 border-b border-slate-100">
                  <CardTitle className="font-semibold flex items-center text-base">
                    <span className="material-icons mr-2 text-primary-500">shield</span>
                    الحماية والرقابة
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-4">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                  >
                    <span className="material-icons ml-2">block</span>
                    حظر التطبيقات الضارة
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                  >
                    <span className="material-icons ml-2">timer</span>
                    جدولة أوقات الاستخدام
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                  >
                    <span className="material-icons ml-2">history</span>
                    سجل النشاط التفصيلي
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                  >
                    <span className="material-icons ml-2">format_list_bulleted</span>
                    التصنيف العمري للتطبيقات
                  </Button>

                  <div className="p-3 bg-blue-50 rounded-lg border border-blue-100 text-sm text-blue-700 mt-4">
                    <p className="flex items-start">
                      <span className="material-icons text-blue-500 ml-2 mt-0.5 text-base">info</span>
                      <span>يمكنك تحديد ساعات استخدام محددة لكل تطبيق أو حظر تطبيقات معينة تمامًا.</span>
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
