import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, formatDistance } from "date-fns";
import { ar } from "date-fns/locale";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format a date in Arabic format
export function formatDate(date: Date | string, pattern: string = "yyyy-MM-dd HH:mm"): string {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  return format(dateObj, pattern, { locale: ar });
}

// Format a relative time in Arabic (e.g., "منذ 5 دقائق")
export function formatRelativeTime(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  return formatDistance(dateObj, new Date(), {
    addSuffix: true,
    locale: ar,
  });
}

// Format seconds to minutes:seconds format
export function formatDuration(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`;
}

// Format seconds to hours and minutes
export function formatHoursMinutes(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }
  return `${minutes}m`;
}

// Format duration in Arabic
export function formatDurationArabic(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (hours > 0 && minutes > 0) {
    return `${hours} ساعة ${minutes} دقيقة`;
  } else if (hours > 0) {
    return `${hours} ساعة`;
  } else {
    return `${minutes} دقيقة`;
  }
}

// Calculate percentage of a value against a maximum
export function calculatePercentage(value: number, max: number): number {
  return Math.min(Math.round((value / max) * 100), 100);
}

// Convert degrees to radians
export function degreesToRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

// Calculate distance between two coordinates using Haversine formula
export function calculateDistance(
  lat1: number, 
  lon1: number, 
  lat2: number, 
  lon2: number
): number {
  const R = 6371; // Radius of the Earth in km
  const dLat = degreesToRadians(lat2 - lat1);
  const dLon = degreesToRadians(lon2 - lon1);
  
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(degreesToRadians(lat1)) * Math.cos(degreesToRadians(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c;
  
  return distance;
}

// Check if a point is inside a circle (for geofencing)
export function isPointInCircle(
  pointLat: number, 
  pointLon: number, 
  circleLat: number, 
  circleLon: number, 
  radiusKm: number
): boolean {
  const distance = calculateDistance(pointLat, pointLon, circleLat, circleLon);
  return distance <= radiusKm;
}
