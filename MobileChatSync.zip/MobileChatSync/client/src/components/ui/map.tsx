import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import "leaflet/dist/leaflet.css";

interface MapProps extends React.HTMLAttributes<HTMLDivElement> {
  latitude: string;
  longitude: string;
  zoom?: number;
  markers?: {
    latitude: string;
    longitude: string;
    tooltip?: string;
    isChild?: boolean;
  }[];
  safeZones?: {
    id: number;
    name: string;
    latitude: string;
    longitude: string;
    radius: number;
  }[];
  height?: string;
  onMapClick?: (lat: number, lng: number) => void;
}

export function Map({
  latitude,
  longitude,
  zoom = 15,
  markers = [],
  safeZones = [],
  height = "400px",
  onMapClick,
  className,
  ...props
}: MapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const leafletMapRef = useRef<any>(null);
  const markersLayerRef = useRef<any>(null);
  const safeZonesLayerRef = useRef<any>(null);

  useEffect(() => {
    let mounted = true;
    const loadLeaflet = async () => {
      try {
        // Dynamically import Leaflet
        const L = await import("leaflet");

        // Create map if not already created
        if (!leafletMapRef.current && mapRef.current) {
          // Initialize the map
          leafletMapRef.current = L.map(mapRef.current).setView(
            [parseFloat(latitude), parseFloat(longitude)],
            zoom
          );

          // Add OpenStreetMap tiles
          L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution:
              '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
          }).addTo(leafletMapRef.current);

          // Create layers for markers and safe zones
          markersLayerRef.current = L.layerGroup().addTo(leafletMapRef.current);
          safeZonesLayerRef.current = L.layerGroup().addTo(leafletMapRef.current);

          // Add click event if handler provided
          if (onMapClick) {
            leafletMapRef.current.on("click", (e: any) => {
              onMapClick(e.latlng.lat, e.latlng.lng);
            });
          }
        } else if (leafletMapRef.current) {
          // Update view if map already exists
          leafletMapRef.current.setView(
            [parseFloat(latitude), parseFloat(longitude)],
            zoom
          );
        }

        // Update markers
        if (markersLayerRef.current) {
          markersLayerRef.current.clearLayers();

          // Custom icons
          const childIcon = L.divIcon({
            className: "custom-div-icon",
            html: `<div class="relative">
                    <span class="absolute -top-2 -right-2 animate-ping bg-primary-500 rounded-full w-4 h-4 opacity-75"></span>
                    <span class="absolute -top-2 -right-2 bg-primary-600 rounded-full w-4 h-4"></span>
                   </div>`,
            iconSize: [30, 30],
            iconAnchor: [15, 15],
          });

          const defaultIcon = L.divIcon({
            className: "custom-div-icon",
            html: `<div class="bg-primary-600 p-1 rounded-full">
                    <div class="w-2 h-2 bg-white rounded-full"></div>
                   </div>`,
            iconSize: [20, 20],
            iconAnchor: [10, 10],
          });

          // Add markers
          markers.forEach((marker) => {
            const markerObject = L.marker(
              [parseFloat(marker.latitude), parseFloat(marker.longitude)],
              { icon: marker.isChild ? childIcon : defaultIcon }
            );

            if (marker.tooltip) {
              markerObject.bindTooltip(marker.tooltip);
            }

            markerObject.addTo(markersLayerRef.current);
          });
        }

        // Update safe zones
        if (safeZonesLayerRef.current) {
          safeZonesLayerRef.current.clearLayers();

          // Add safe zones as circles
          safeZones.forEach((zone) => {
            const circle = L.circle(
              [parseFloat(zone.latitude), parseFloat(zone.longitude)],
              {
                radius: zone.radius,
                color: "#4f46e5", // secondary-600
                fillColor: "#818cf8", // secondary-400
                fillOpacity: 0.2,
                weight: 1,
              }
            );

            circle.bindTooltip(zone.name);
            circle.addTo(safeZonesLayerRef.current);
          });
        }

        if (mounted) {
          setIsLoading(false);
        }
      } catch (error) {
        console.error("Error loading Leaflet:", error);
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    loadLeaflet();

    return () => {
      mounted = false;
      if (leafletMapRef.current) {
        leafletMapRef.current.remove();
        leafletMapRef.current = null;
      }
    };
  }, [latitude, longitude, zoom, markers, safeZones, onMapClick]);

  return (
    <div
      className={cn("relative rounded-lg overflow-hidden", className)}
      style={{ height }}
      {...props}
    >
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-100">
          <div className="text-center p-4">
            <svg
              className="animate-spin h-10 w-10 text-primary-500 mx-auto mb-4"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              ></circle>
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              ></path>
            </svg>
            <p className="text-slate-500">جاري تحميل الخريطة...</p>
          </div>
        </div>
      )}
      <div ref={mapRef} className="h-full w-full"></div>
    </div>
  );
}
