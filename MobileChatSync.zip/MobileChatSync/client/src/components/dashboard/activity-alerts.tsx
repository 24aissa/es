import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useChild } from "@/contexts/child-context";
import { apiRequest } from "@/lib/queryClient";
import { formatRelativeTime } from "@/lib/utils";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function ActivityAlerts() {
  const { selectedChild } = useChild();
  const [activityPeriod, setActivityPeriod] = useState("today");

  // Fetch alerts
  const { data: alerts = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/alerts?limit=3`],
    enabled: !!selectedChild?.id,
  });

  // Fetch activities
  const { data: activities = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/activities?limit=4`],
    enabled: !!selectedChild?.id,
  });

  // Mark alert as read
  const markAlertAsRead = useMutation({
    mutationFn: async (alertId: number) => {
      return await apiRequest("PATCH", `/api/alerts/${alertId}/read`, undefined);
    },
    onSuccess: () => {
      // Refetch alerts after marking as read
      queryClient.invalidateQueries({
        queryKey: [`/api/children/${selectedChild?.id}/alerts`],
      });
    },
  });

  const handleMarkAlertAsRead = (alertId: number) => {
    markAlertAsRead.mutate(alertId);
  };

  // Helper function to get appropriate icon and background for alert type
  const getAlertStyles = (type: string, severity: string) => {
    let icon = "error";
    let bgClass = "bg-danger bg-opacity-5 border border-danger border-opacity-10";
    let iconClass = "text-danger";

    if (type === "location") {
      icon = "location_off";
      if (severity === "warning") {
        bgClass = "bg-warning bg-opacity-5 border border-warning border-opacity-10";
        iconClass = "text-warning";
      }
    } else if (type === "app") {
      icon = "download";
      if (severity === "info") {
        bgClass = "bg-slate-50 border border-slate-100";
        iconClass = "text-secondary-500";
      }
    }

    return { icon, bgClass, iconClass };
  };

  // Helper function to get appropriate icon for activity type
  const getActivityIcon = (type: string) => {
    switch (type) {
      case "call":
        return "call";
      case "message":
        return "message";
      case "browsing":
        return "language";
      case "app":
        return "schedule";
      default:
        return "update";
    }
  };

  return (
    <div className="space-y-6">
      {/* Alerts Section */}
      <Card className="shadow-sm">
        <CardHeader className="flex justify-between items-center py-4 px-4 border-b border-slate-100">
          <CardTitle className="font-semibold flex items-center text-base">
            <span className="material-icons mr-2 text-warning">warning</span>
            التنبيهات
          </CardTitle>
          {alerts.length > 0 && (
            <Badge className="bg-warning text-white px-2 py-1">
              {alerts.length} جديد
            </Badge>
          )}
        </CardHeader>

        <CardContent className="p-4">
          <div className="space-y-3">
            {alerts.map((alert: any) => {
              const { icon, bgClass, iconClass } = getAlertStyles(
                alert.type,
                alert.severity
              );
              return (
                <div
                  key={alert.id}
                  className={`flex p-3 rounded-lg ${bgClass}`}
                >
                  <span className={`material-icons ${iconClass} ml-3`}>
                    {icon}
                  </span>
                  <div className="flex-grow">
                    <div className="flex justify-between items-start">
                      <p className="font-medium">{alert.message}</p>
                      <span className="text-xs text-slate-500">
                        {formatRelativeTime(alert.timestamp)}
                      </span>
                    </div>
                    <p className="text-sm text-slate-600 mt-1">
                      {typeof alert.details === "object"
                        ? Object.values(alert.details)[0]
                        : alert.details}
                    </p>
                  </div>
                </div>
              );
            })}

            {alerts.length === 0 && (
              <div className="text-center py-6 text-slate-500">
                لا توجد تنبيهات جديدة
              </div>
            )}
          </div>

          <Button
            variant="link"
            className="mt-4 w-full text-primary-600 hover:text-primary-800 font-medium"
            onClick={() => {}}
          >
            عرض جميع التنبيهات
          </Button>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card className="shadow-sm">
        <CardHeader className="flex justify-between items-center py-4 px-4 border-b border-slate-100">
          <CardTitle className="font-semibold flex items-center text-base">
            <span className="material-icons mr-2 text-primary-500">update</span>
            النشاط الأخير
          </CardTitle>
          <Select
            value={activityPeriod}
            onValueChange={setActivityPeriod}
          >
            <SelectTrigger className="w-32 h-7 text-xs border-0 bg-slate-50 rounded">
              <SelectValue placeholder="اختر الفترة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">اليوم</SelectItem>
              <SelectItem value="week">هذا الأسبوع</SelectItem>
              <SelectItem value="month">هذا الشهر</SelectItem>
            </SelectContent>
          </Select>
        </CardHeader>

        <CardContent className="p-0">
          <div className="divide-y divide-slate-100">
            {activities.map((activity: any) => (
              <div key={activity.id} className="flex items-center p-4">
                <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center ml-3 flex-shrink-0">
                  <span className="material-icons text-primary-500 text-sm">
                    {getActivityIcon(activity.type)}
                  </span>
                </div>
                <div className="flex-grow">
                  <p className="text-sm font-medium">
                    {activity.type === "call" && (
                      <>مكالمة مع {activity.details.contactName}</>
                    )}
                    {activity.type === "message" && (
                      <>رسالة من {activity.details.contactName}</>
                    )}
                    {activity.type === "browsing" && (
                      <>تصفح موقع {activity.details.site}</>
                    )}
                    {activity.type === "app" && (
                      <>فتح تطبيق {activity.details.appName}</>
                    )}
                  </p>
                  <p className="text-xs text-slate-500">
                    {activity.type === "call" && activity.details.duration}
                    {activity.type === "message" && activity.details.content}
                    {activity.type === "browsing" && (
                      <>البحث عن "{activity.details.search}"</>
                    )}
                    {activity.type === "app" && (
                      <>لمدة {activity.details.duration}</>
                    )}
                  </p>
                </div>
                <span className="text-xs text-slate-500">
                  {formatRelativeTime(activity.timestamp)}
                </span>
              </div>
            ))}

            {activities.length === 0 && (
              <div className="text-center py-8 text-slate-500">
                لا يوجد نشاط حديث
              </div>
            )}
          </div>

          <div className="p-4 border-t border-slate-100">
            <Button
              variant="link"
              className="w-full text-primary-600 hover:text-primary-800 font-medium"
              onClick={() => {}}
            >
              عرض المزيد من النشاطات
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
