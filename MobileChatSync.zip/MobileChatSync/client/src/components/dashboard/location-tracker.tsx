import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useChild } from "@/contexts/child-context";
import { apiRequest } from "@/lib/queryClient";
import { Map } from "@/components/ui/map";
import { formatRelativeTime } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export function LocationTracker() {
  const { selectedChild } = useChild();
  const [newSafeZoneName, setNewSafeZoneName] = useState("");
  const [newSafeZoneRadius, setNewSafeZoneRadius] = useState(200);
  const [newSafeZoneCoords, setNewSafeZoneCoords] = useState<{
    latitude: string;
    longitude: string;
  } | null>(null);
  const [addingZone, setAddingZone] = useState(false);

  // Fetch locations
  const { data: locations = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/locations?limit=10`],
    enabled: !!selectedChild?.id,
  });

  // Fetch safe zones
  const { data: safeZones = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/safe-zones`],
    enabled: !!selectedChild?.id,
  });

  // Add a new safe zone
  const addSafeZone = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/safe-zones", data);
    },
    onSuccess: () => {
      // Refetch safe zones after adding a new one
      queryClient.invalidateQueries({
        queryKey: [`/api/children/${selectedChild?.id}/safe-zones`],
      });
      setNewSafeZoneName("");
      setNewSafeZoneRadius(200);
      setNewSafeZoneCoords(null);
      setAddingZone(false);
    },
  });

  // Delete a safe zone
  const deleteSafeZone = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/safe-zones/${id}`, undefined);
    },
    onSuccess: () => {
      // Refetch safe zones after deletion
      queryClient.invalidateQueries({
        queryKey: [`/api/children/${selectedChild?.id}/safe-zones`],
      });
    },
  });

  const handleAddSafeZone = () => {
    if (!selectedChild || !newSafeZoneCoords || !newSafeZoneName) return;

    addSafeZone.mutate({
      childId: selectedChild.id,
      name: newSafeZoneName,
      latitude: newSafeZoneCoords.latitude,
      longitude: newSafeZoneCoords.longitude,
      radius: newSafeZoneRadius,
      active: true,
    });
  };

  const handleDeleteSafeZone = (id: number) => {
    deleteSafeZone.mutate(id);
  };

  const handleMapClick = (lat: number, lng: number) => {
    if (addingZone) {
      setNewSafeZoneCoords({
        latitude: lat.toString(),
        longitude: lng.toString(),
      });
    }
  };

  // Get the latest location
  const latestLocation = locations[0];

  return (
    <Card className="shadow-sm">
      <CardHeader className="flex justify-between items-center py-4 px-4 border-b border-slate-100">
        <CardTitle className="font-semibold flex items-center text-base">
          <span className="material-icons mr-2 text-primary-500">location_on</span>
          تتبع الموقع
        </CardTitle>
        <Button
          variant="link"
          size="sm"
          className="text-primary-600 font-medium"
        >
          عرض التفاصيل
        </Button>
      </CardHeader>

      <CardContent className="p-4">
        {/* Map Container */}
        {latestLocation ? (
          <Map
            latitude={latestLocation.latitude}
            longitude={latestLocation.longitude}
            markers={[
              {
                latitude: latestLocation.latitude,
                longitude: latestLocation.longitude,
                tooltip: latestLocation.locationName || "الموقع الحالي",
                isChild: true,
              },
            ]}
            safeZones={safeZones}
            onMapClick={handleMapClick}
            className="mb-4"
          />
        ) : (
          <div className="h-[400px] bg-slate-100 relative rounded-lg">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center p-4">
                <span className="material-icons text-slate-400 text-5xl">map</span>
                <p className="mt-2 text-slate-500">سيتم عرض الخريطة هنا</p>
              </div>
            </div>
          </div>
        )}

        {/* Location History */}
        <div className="mt-4">
          <h4 className="text-sm font-medium text-slate-700 mb-2">سجل المواقع</h4>
          <div className="space-y-3">
            {locations.map((location: any, index: number) => (
              <div
                key={location.id}
                className={`flex items-center text-sm ${
                  index === 0
                    ? "border-r-2 border-primary-500 pr-3"
                    : "border-r-2 border-slate-300 pr-3"
                }`}
              >
                <span
                  className={`material-icons ml-2 text-lg ${
                    index === 0 ? "text-primary-500" : "text-slate-400"
                  }`}
                >
                  location_on
                </span>
                <div className="flex-grow">
                  <p className="font-medium">{location.locationName || "موقع غير معروف"}</p>
                  <p className="text-slate-500 text-xs">
                    {formatRelativeTime(location.timestamp)}
                  </p>
                </div>
              </div>
            ))}

            {locations.length === 0 && (
              <div className="text-center py-4 text-slate-500">
                لا يوجد سجل مواقع
              </div>
            )}
          </div>

          {/* Geofencing Section */}
          <div className="mt-4 bg-slate-50 p-3 rounded-lg">
            <h4 className="flex items-center text-sm font-medium">
              <span className="material-icons text-secondary-500 ml-1 text-sm">
                fence
              </span>
              تحديد منطقة آمنة
            </h4>
            <div className="mt-2 flex flex-wrap gap-2">
              {safeZones.map((zone: any) => (
                <Badge
                  key={zone.id}
                  variant="outline"
                  className="bg-white flex items-center border-slate-200 px-3 py-1 rounded-full text-xs"
                >
                  {zone.name}
                  <button
                    className="material-icons text-slate-400 hover:text-red-500 mr-1 text-xs"
                    onClick={() => handleDeleteSafeZone(zone.id)}
                  >
                    close
                  </button>
                </Badge>
              ))}

              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="bg-secondary-50 text-secondary-600 border-secondary-100 hover:bg-secondary-100 px-3 py-1 h-6 rounded-full text-xs"
                  >
                    <span className="material-icons mr-1 text-xs">add</span>
                    إضافة منطقة
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>إضافة منطقة آمنة جديدة</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="safezone-name">اسم المنطقة</Label>
                      <Input
                        id="safezone-name"
                        value={newSafeZoneName}
                        onChange={(e) => setNewSafeZoneName(e.target.value)}
                        placeholder="مثال: المنزل، المدرسة"
                      />
                    </div>
                    <div>
                      <Label htmlFor="safezone-radius">نصف القطر (متر)</Label>
                      <Input
                        id="safezone-radius"
                        type="number"
                        value={newSafeZoneRadius}
                        onChange={(e) => setNewSafeZoneRadius(Number(e.target.value))}
                        min={50}
                        max={1000}
                      />
                    </div>
                    <div>
                      <Label>الموقع</Label>
                      <p className="text-sm text-slate-500 mb-2">
                        {addingZone
                          ? "انقر على الخريطة لتحديد الموقع"
                          : "اضغط على زر تحديد الموقع"}
                      </p>
                      <Button
                        variant="outline"
                        type="button"
                        onClick={() => setAddingZone(!addingZone)}
                      >
                        {addingZone ? "إلغاء" : "تحديد الموقع على الخريطة"}
                      </Button>
                      {newSafeZoneCoords && (
                        <p className="mt-2 text-sm text-green-600">
                          تم اختيار الموقع بنجاح!
                        </p>
                      )}
                    </div>
                    <div className="flex justify-end gap-2 mt-4">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setAddingZone(false);
                          setNewSafeZoneCoords(null);
                        }}
                      >
                        إلغاء
                      </Button>
                      <Button
                        onClick={handleAddSafeZone}
                        disabled={!newSafeZoneName || !newSafeZoneCoords}
                      >
                        إضافة
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
