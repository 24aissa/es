import { useState } from "react";
import { useChild } from "@/contexts/child-context";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export function Header({ title, subtitle }: HeaderProps) {
  const { selectedChild, setSelectedChild } = useChild();
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  // Fetch children for the dropdown
  const { data: children = [] } = useQuery({
    queryKey: ["/api/children?parentId=1"],
  });

  // Fetch unread alerts count
  const { data: alerts = [] } = useQuery({
    queryKey: [
      `/api/children/${selectedChild?.id}/alerts?includeRead=false`,
    ],
    enabled: !!selectedChild?.id,
  });

  const unreadAlertsCount = alerts.length;

  return (
    <header className="bg-white border-b border-slate-200 p-4 flex items-center justify-between sticky top-0 z-10">
      <div dir="rtl">
        <h2 className="text-xl font-semibold">{title}</h2>
        {subtitle && <p className="text-slate-500 text-sm">{subtitle}</p>}
      </div>

      {/* User actions */}
      <div className="flex items-center gap-4">
        {/* Notifications */}
        <div className="relative">
          <button
            className="p-2 rounded-full hover:bg-slate-100 relative"
            onClick={() => setNotificationsOpen(!notificationsOpen)}
          >
            <span className="material-icons">notifications</span>
            {unreadAlertsCount > 0 && (
              <span className="absolute top-1 right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {unreadAlertsCount}
              </span>
            )}
          </button>
        </div>

        {/* Child Selector */}
        <div className="relative">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                className="bg-slate-100 border border-slate-200 rounded-lg py-2 px-3 text-sm"
              >
                {selectedChild ? `${selectedChild.name}` : "اختر طفل"}
                <span className="material-icons text-slate-500 mr-2 text-sm">
                  arrow_drop_down
                </span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {children.map((child: any) => (
                <DropdownMenuItem
                  key={child.id}
                  onClick={() => setSelectedChild(child)}
                >
                  {child.name}
                </DropdownMenuItem>
              ))}
              <DropdownMenuItem>
                <span className="material-icons text-primary-500 ml-2 text-sm">
                  add_circle
                </span>
                إضافة طفل
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
