import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigationItems = [
    {
      name: "لوحة المعلومات",
      icon: "dashboard",
      href: "/",
    },
    {
      name: "تتبع الموقع",
      icon: "location_on",
      href: "/location",
    },
    {
      name: "سجل المكالمات",
      icon: "call",
      href: "/calls",
    },
    {
      name: "الرسائل النصية",
      icon: "message",
      href: "/messages",
    },
    {
      name: "التطبيقات المثبتة",
      icon: "apps",
      href: "/apps",
    },
    {
      name: "سجل التصفح",
      icon: "public",
      href: "/browsing",
    },
    {
      name: "وسائل التواصل",
      icon: "group",
      href: "/social-media",
    },
    {
      name: "التنبيهات",
      icon: "notifications",
      href: "/alerts",
    },
    {
      name: "الإعدادات",
      icon: "settings",
      href: "/settings",
    },
  ];

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <aside
      className={cn(
        "bg-slate-800 text-white w-full md:w-64 flex-shrink-0 md:flex flex-col md:fixed md:inset-y-0 z-10",
        className
      )}
    >
      {/* Logo */}
      <div className="p-4 flex items-center justify-between md:justify-center border-b border-slate-700">
        <div className="flex items-center space-x-2 space-x-reverse">
          <span className="material-icons text-primary-500">family_restroom</span>
          <h1 className="text-xl font-bold">نظام المراقبة الأبوي</h1>
        </div>
        {/* Mobile menu button */}
        <button className="md:hidden" onClick={toggleMobileMenu}>
          <span className="material-icons">
            {isMobileMenuOpen ? "close" : "menu"}
          </span>
        </button>
      </div>

      {/* Navigation Menu */}
      <nav
        className={cn(
          "md:block py-4 md:pt-6 h-full overflow-y-auto scrollbar-thin",
          isMobileMenuOpen ? "block" : "hidden"
        )}
      >
        <ul>
          {navigationItems.map((item) => (
            <li key={item.href}>
              <Link href={item.href}>
                <a
                  className={cn(
                    "flex items-center px-4 py-3",
                    location === item.href
                      ? "bg-primary-600 text-white"
                      : "text-slate-300 hover:bg-slate-700 transition-colors duration-200"
                  )}
                >
                  <span className="material-icons ml-3">{item.icon}</span>
                  <span>{item.name}</span>
                </a>
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      {/* User Profile */}
      <div className="mt-auto p-4 border-t border-slate-700 hidden md:flex items-center">
        <img
          src="https://images.unsplash.com/photo-1607746882042-944635dfe10e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&q=80"
          alt="صورة المستخدم"
          className="w-10 h-10 rounded-full ml-3"
        />
        <div>
          <p className="font-medium text-sm">أحمد محمد</p>
          <p className="text-slate-400 text-xs">الحساب الأساسي</p>
        </div>
      </div>
    </aside>
  );
}
