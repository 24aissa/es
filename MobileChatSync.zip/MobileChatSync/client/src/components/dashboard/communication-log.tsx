import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useChild } from "@/contexts/child-context";
import { formatRelativeTime, formatDurationArabic } from "@/lib/utils";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function CommunicationLog() {
  const { selectedChild } = useChild();
  const [filterType, setFilterType] = useState("all"); // 'all', 'calls', 'messages'

  // Fetch calls
  const { data: calls = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/calls?limit=10`],
    enabled: !!selectedChild?.id && (filterType === "all" || filterType === "calls"),
  });

  // Fetch messages
  const { data: messages = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/messages?limit=10`],
    enabled: !!selectedChild?.id && (filterType === "all" || filterType === "messages"),
  });

  // Combine and sort communications
  const communications = [
    ...calls.map((call: any) => ({
      ...call,
      type: "call",
      contactName: call.contactName || call.phoneNumber,
      formattedTime: formatRelativeTime(call.timestamp),
    })),
    ...messages.map((message: any) => ({
      ...message,
      type: "message",
      contactName: message.contactName || message.phoneNumber,
      formattedTime: formatRelativeTime(message.timestamp),
    })),
  ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  // Filter communications based on type
  const filteredCommunications =
    filterType === "all"
      ? communications
      : communications.filter((comm) => comm.type === filterType);

  return (
    <Card className="shadow-sm">
      <CardHeader className="flex justify-between items-center py-4 px-4 border-b border-slate-100">
        <CardTitle className="font-semibold flex items-center text-base">
          <span className="material-icons mr-2 text-primary-500">call</span>
          سجل الاتصالات والرسائل
        </CardTitle>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-28 h-7 text-xs border-0 bg-slate-50 rounded">
            <SelectValue placeholder="اختر النوع" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">الكل</SelectItem>
            <SelectItem value="call">المكالمات</SelectItem>
            <SelectItem value="message">الرسائل</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>

      <CardContent className="p-0">
        <div className="divide-y divide-slate-100">
          {filteredCommunications.length > 0 ? (
            filteredCommunications.map((comm) => (
              <div key={`${comm.type}-${comm.id}`} className="flex items-center p-3">
                <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center ml-3 flex-shrink-0">
                  <span className="material-icons text-primary-500 text-sm">
                    {comm.type === "call" ? "call" : "message"}
                  </span>
                </div>
                <div className="flex-grow">
                  <div className="flex justify-between">
                    <p className="text-sm font-medium">{comm.contactName}</p>
                    <div className="flex items-center">
                      {comm.type === "call" && comm.duration > 0 && (
                        <span className="text-xs text-green-600 ml-1">
                          {formatDurationArabic(comm.duration)}
                        </span>
                      )}
                      <span className="text-xs text-slate-500">{comm.formattedTime}</span>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 flex items-center">
                    {comm.type === "call" ? (
                      <>
                        <span
                          className={`material-icons text-xs ml-1 ${
                            comm.callType === "incoming"
                              ? "text-primary-500"
                              : comm.callType === "outgoing"
                              ? "text-success"
                              : "text-danger"
                          }`}
                        >
                          {comm.callType === "incoming"
                            ? "call_received"
                            : comm.callType === "outgoing"
                            ? "call_made"
                            : "call_missed"}
                        </span>
                        {comm.callType === "incoming"
                          ? "مكالمة واردة"
                          : comm.callType === "outgoing"
                          ? "مكالمة صادرة"
                          : "مكالمة فائتة"}
                      </>
                    ) : (
                      comm.content.substring(0, 50) +
                      (comm.content.length > 50 ? "..." : "")
                    )}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-slate-500">
              لا توجد {filterType === "call" ? "مكالمات" : filterType === "message" ? "رسائل" : "اتصالات"} لعرضها
            </div>
          )}
        </div>

        <div className="p-4 border-t border-slate-100">
          <Button
            variant="link"
            className="w-full py-2 text-sm text-center text-primary-600 hover:text-primary-800 font-medium"
          >
            عرض السجل الكامل
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
