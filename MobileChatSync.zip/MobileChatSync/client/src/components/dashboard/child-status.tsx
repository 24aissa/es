import { useQuery } from "@tanstack/react-query";
import { Child } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { formatRelativeTime } from "@/lib/utils";

interface ChildStatusProps {
  child: Child;
}

export function ChildStatus({ child }: ChildStatusProps) {
  // Fetch the latest location
  const { data: latestLocation } = useQuery({
    queryKey: [`/api/children/${child.id}/locations/latest`],
    enabled: !!child,
  });

  // Fetch recent activities
  const { data: activities = [] } = useQuery({
    queryKey: [`/api/children/${child.id}/activities?limit=4`],
    enabled: !!child,
  });

  // Find the most recent activities by type
  const getLatestActivityByType = (type: string) => {
    return activities
      .filter((a: any) => a.type === type)
      .sort(
        (a: any, b: any) =>
          new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      )[0];
  };

  const latestCall = getLatestActivityByType("call");
  const latestMessage = getLatestActivityByType("message");
  const latestApp = getLatestActivityByType("app");
  const latestBrowsing = getLatestActivityByType("browsing");

  // Calculate battery percentage from device info
  const batteryMatch = child.deviceInfo.match(/باقي (\d+)% بطارية/);
  const batteryPercentage = batteryMatch ? batteryMatch[1] : "65";

  return (
    <div className="bg-white rounded-xl shadow-sm p-4 md:p-6 mb-6">
      <div className="flex flex-wrap md:flex-nowrap items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="relative">
            <img
              src={child.profileImage || "https://images.unsplash.com/photo-1499952127939-9bbf5af6c51c"}
              alt={`صورة ${child.name}`}
              className="w-20 h-20 rounded-full border-4 border-primary-100 object-cover"
            />
            <span className="absolute bottom-0 right-0 w-5 h-5 bg-green-500 rounded-full border-2 border-white"></span>
          </div>

          <div>
            <h3 className="text-xl font-semibold">{child.name}</h3>
            <div className="flex items-center text-sm text-slate-500">
              <span className="material-icons text-green-500 text-base ml-1">
                location_on
              </span>
              <span>
                {latestLocation ? (
                  <>
                    {latestLocation.locationName} (
                    {formatRelativeTime(latestLocation.timestamp)})
                  </>
                ) : (
                  "غير متوفر"
                )}
              </span>
            </div>
            <div className="flex items-center text-sm text-slate-500 mt-1">
              <span className="material-icons text-slate-400 text-base ml-1">
                phone_android
              </span>
              <span>
                {child.deviceInfo} (باقي {batteryPercentage}% بطارية)
              </span>
            </div>
          </div>
        </div>

        <div className="flex-grow grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 md:mt-0">
          {/* Last Activity Stats */}
          <div className="bg-slate-50 rounded-lg p-3 border border-slate-100">
            <div className="flex items-center">
              <span className="material-icons text-primary-500 ml-2">call</span>
              <div>
                <p className="text-xs text-slate-500">آخر مكالمة</p>
                <p className="text-sm font-medium">
                  {latestCall ? (
                    <>
                      {latestCall.details.contactName} ({formatRelativeTime(latestCall.timestamp)})
                    </>
                  ) : (
                    "لا يوجد"
                  )}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 rounded-lg p-3 border border-slate-100">
            <div className="flex items-center">
              <span className="material-icons text-primary-500 ml-2">message</span>
              <div>
                <p className="text-xs text-slate-500">آخر رسالة</p>
                <p className="text-sm font-medium">
                  {latestMessage ? (
                    <>
                      {latestMessage.details.contactName} ({formatRelativeTime(latestMessage.timestamp)})
                    </>
                  ) : (
                    "لا يوجد"
                  )}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 rounded-lg p-3 border border-slate-100">
            <div className="flex items-center">
              <span className="material-icons text-primary-500 ml-2">apps</span>
              <div>
                <p className="text-xs text-slate-500">آخر تطبيق</p>
                <p className="text-sm font-medium">
                  {latestApp ? (
                    <>
                      {latestApp.details.appName} ({latestApp.details.duration})
                    </>
                  ) : (
                    "لا يوجد"
                  )}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 rounded-lg p-3 border border-slate-100">
            <div className="flex items-center">
              <span className="material-icons text-primary-500 ml-2">public</span>
              <div>
                <p className="text-xs text-slate-500">آخر تصفح</p>
                <p className="text-sm font-medium">
                  {latestBrowsing ? (
                    <>
                      {latestBrowsing.details.site} ({formatRelativeTime(latestBrowsing.timestamp)})
                    </>
                  ) : (
                    "لا يوجد"
                  )}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mt-6 flex flex-wrap gap-2">
        <Button
          variant="outline"
          className="bg-primary-50 text-primary-700 border-primary-100 hover:bg-primary-100"
        >
          <span className="material-icons ml-1 text-sm">message</span>
          إرسال رسالة
        </Button>
        <Button variant="outline" className="bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200">
          <span className="material-icons ml-1 text-sm">lock</span>
          قفل الجهاز
        </Button>
        <Button variant="outline" className="bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200">
          <span className="material-icons ml-1 text-sm">notifications_off</span>
          وضع صامت
        </Button>
        <Button 
          variant="outline"
          className="bg-red-50 text-red-600 border-red-100 hover:bg-red-100"
        >
          <span className="material-icons ml-1 text-sm">feedback</span>
          خطر محتمل
        </Button>
      </div>
    </div>
  );
}
