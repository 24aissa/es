import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useChild } from "@/contexts/child-context";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { formatRelativeTime } from "@/lib/utils";

export function AppMonitoring() {
  const { selectedChild } = useChild();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch apps
  const { data: apps = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/apps`],
    enabled: !!selectedChild?.id,
  });

  // Toggle app blocking
  const toggleAppBlocking = useMutation({
    mutationFn: async ({ appId, isBlocked }: { appId: number; isBlocked: boolean }) => {
      return await apiRequest("PATCH", `/api/apps/${appId}`, { isBlocked });
    },
    onSuccess: () => {
      // Refetch apps after toggling
      queryClient.invalidateQueries({
        queryKey: [`/api/children/${selectedChild?.id}/apps`],
      });
    },
  });

  const handleToggleAppBlocking = (appId: number, isBlocked: boolean) => {
    toggleAppBlocking.mutate({ appId, isBlocked: !isBlocked });
  };

  // Filter apps by search query
  const filteredApps = apps.filter((app: any) =>
    app.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Get gradient background color for app icon based on app name
  const getAppGradient = (appName: string) => {
    const gradients = [
      "bg-gradient-to-br from-purple-500 to-pink-500",
      "bg-gradient-to-br from-cyan-500 to-blue-500",
      "bg-gradient-to-br from-red-500 to-orange-500",
      "bg-gradient-to-br from-red-500 to-red-600",
      "bg-gradient-to-br from-green-500 to-emerald-600",
      "bg-gradient-to-br from-yellow-500 to-orange-500",
      "bg-gradient-to-br from-blue-500 to-indigo-600",
    ];

    // Simple hash function to get a consistent gradient for the same app name
    const hash = appName.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return gradients[hash % gradients.length];
  };

  // Get icon for app based on app name/category
  const getAppIcon = (app: any) => {
    if (app.name.toLowerCase().includes("instagram")) return "photo";
    if (app.name.toLowerCase().includes("whatsapp")) return "message";
    if (app.name.toLowerCase().includes("tiktok")) return "videocam";
    if (app.name.toLowerCase().includes("youtube")) return "smart_display";
    if (app.name.toLowerCase().includes("spotify")) return "music_note";
    if (app.name.toLowerCase().includes("facebook")) return "thumb_up";
    if (app.name.toLowerCase().includes("twitter")) return "trending_up";
    if (app.name.toLowerCase().includes("snapchat")) return "visibility";
    if (app.name.toLowerCase().includes("camera")) return "camera_alt";
    if (app.name.toLowerCase().includes("games")) return "sports_esports";
    if (app.name.toLowerCase().includes("maps")) return "map";
    
    // Default icon based on category
    if (app.category?.toLowerCase().includes("تطبيق اجتماعي")) return "people";
    if (app.category?.toLowerCase().includes("فيديو")) return "video_library";
    if (app.category?.toLowerCase().includes("مراسلة")) return "chat";
    if (app.category?.toLowerCase().includes("موسيقى")) return "music_note";
    
    // Fallback
    return "apps";
  };

  return (
    <Card className="shadow-sm">
      <CardHeader className="flex justify-between items-center py-4 px-4 border-b border-slate-100">
        <CardTitle className="font-semibold flex items-center text-base">
          <span className="material-icons mr-2 text-primary-500">apps</span>
          التطبيقات المثبتة
        </CardTitle>
        <Badge className="bg-primary-100 text-primary-700">
          {apps.length} تطبيق
        </Badge>
      </CardHeader>

      <CardContent className="p-4">
        <div className="flex justify-between mb-3">
          <div className="relative w-full">
            <Input
              type="text"
              placeholder="بحث في التطبيقات"
              className="w-full pr-8 pl-2 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <span className="material-icons absolute right-2 top-1.5 text-slate-400 text-sm">
              search
            </span>
          </div>
        </div>

        <div className="h-64 overflow-y-auto scrollbar-thin">
          {filteredApps.length > 0 ? (
            filteredApps.map((app: any) => (
              <div
                key={app.id}
                className="flex justify-between items-center p-2 hover:bg-slate-50 rounded-lg"
              >
                <div className="flex items-center">
                  <div className={`w-8 h-8 rounded-lg ${getAppGradient(app.name)} flex items-center justify-center ml-2`}>
                    <span className="material-icons text-white text-sm">
                      {getAppIcon(app)}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium">{app.name}</p>
                    <p className="text-xs text-slate-500">
                      {app.category || "تطبيق"}
                      {" - "}
                      {formatRelativeTime(app.installDate)}
                    </p>
                  </div>
                </div>
                <Switch
                  checked={!app.isBlocked}
                  onCheckedChange={() => handleToggleAppBlocking(app.id, app.isBlocked)}
                />
              </div>
            ))
          ) : (
            <div className="text-center py-10 text-slate-500">
              لا توجد تطبيقات مطابقة
            </div>
          )}
        </div>

        <div className="mt-4 flex flex-col space-y-2">
          <Button
            variant="outline"
            className="py-2 text-sm text-center text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50 font-medium transition-colors"
          >
            <span className="material-icons inline-block align-text-bottom ml-1 text-sm">
              block
            </span>
            تعطيل تطبيقات محددة
          </Button>
          <Button
            variant="outline"
            className="py-2 text-sm text-center text-primary-600 border border-primary-200 rounded-lg hover:bg-primary-50 font-medium transition-colors"
          >
            <span className="material-icons inline-block align-text-bottom ml-1 text-sm">
              manage_search
            </span>
            سجل استخدام التطبيقات
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
