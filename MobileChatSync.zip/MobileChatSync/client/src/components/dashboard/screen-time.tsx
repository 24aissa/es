import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useChild } from "@/contexts/child-context";
import { apiRequest } from "@/lib/queryClient";
import { formatDurationArabic, calculatePercentage } from "@/lib/utils";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function ScreenTime() {
  const { selectedChild } = useChild();
  const [period, setPeriod] = useState("today");
  const [dailyLimit, setDailyLimit] = useState<number>(0);
  const [appSpecificLimits, setAppSpecificLimits] = useState<{ [key: number]: number }>({});

  // Fetch screen time limit
  const { data: screenTimeLimit } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/screen-time-limit`],
    enabled: !!selectedChild?.id,
    onSuccess: (data) => {
      if (data) {
        setDailyLimit(data.dailyLimit);
        setAppSpecificLimits(data.appSpecificLimits || {});
      }
    },
  });

  // Fetch app usage
  const { data: appUsage = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/app-usage`],
    enabled: !!selectedChild?.id,
  });

  // Fetch apps
  const { data: apps = [] } = useQuery({
    queryKey: [`/api/children/${selectedChild?.id}/apps`],
    enabled: !!selectedChild?.id,
  });

  // Update screen time limit
  const updateScreenTimeLimit = useMutation({
    mutationFn: async (data: any) => {
      if (screenTimeLimit) {
        return await apiRequest("PATCH", `/api/screen-time-limits/${screenTimeLimit.id}`, data);
      } else {
        return await apiRequest("POST", "/api/screen-time-limits", data);
      }
    },
    onSuccess: () => {
      // Refetch screen time limit after updating
      queryClient.invalidateQueries({
        queryKey: [`/api/children/${selectedChild?.id}/screen-time-limit`],
      });
    },
  });

  const handleUpdateScreenTimeLimit = () => {
    if (!selectedChild) return;

    updateScreenTimeLimit.mutate({
      childId: selectedChild.id,
      dailyLimit,
      appSpecificLimits,
    });
  };

  // Calculate total app usage duration
  const totalUsageDuration = appUsage.reduce(
    (total: number, app: any) => total + app.duration,
    0
  );

  // Map app IDs to names
  const appMap = apps.reduce((map: { [key: number]: any }, app: any) => {
    map[app.id] = app;
    return map;
  }, {});

  // Group app usage by app
  const appUsageByApp = appUsage.reduce((grouped: { [key: number]: number }, usage: any) => {
    const appId = usage.appId;
    if (!grouped[appId]) {
      grouped[appId] = 0;
    }
    grouped[appId] += usage.duration;
    return grouped;
  }, {});

  // Convert to array and sort by duration
  const sortedAppUsage = Object.entries(appUsageByApp).map(([appId, duration]) => ({
    appId: parseInt(appId),
    duration: duration as number,
    name: appId === "0" ? "أخرى" : (appMap[parseInt(appId)]?.name || "تطبيق غير معروف"),
  })).sort((a, b) => b.duration - a.duration);

  // Get app color based on index
  const getAppColor = (index: number) => {
    const colors = ["bg-primary-500", "bg-secondary-500", "bg-warning", "bg-green-500", "bg-slate-400"];
    return colors[index % colors.length];
  };

  // Calculate usage percentage against daily limit
  const usagePercentage = screenTimeLimit
    ? calculatePercentage(totalUsageDuration / 60, screenTimeLimit.dailyLimit)
    : 0;

  return (
    <Card className="shadow-sm">
      <CardHeader className="flex justify-between items-center py-4 px-4 border-b border-slate-100">
        <CardTitle className="font-semibold flex items-center text-base">
          <span className="material-icons mr-2 text-primary-500">access_time</span>
          وقت الاستخدام
        </CardTitle>
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-28 h-7 text-xs border-0 bg-slate-50 rounded">
            <SelectValue placeholder="اختر الفترة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">اليوم</SelectItem>
            <SelectItem value="weekly">أسبوعي</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>

      <CardContent className="p-4">
        {/* Progress Bar */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm font-medium">
              {formatDurationArabic(totalUsageDuration)}
            </span>
            <span className="text-xs text-slate-500">
              الحد: {screenTimeLimit ? formatDurationArabic(screenTimeLimit.dailyLimit * 60) : "غير محدد"}
            </span>
          </div>
          <Progress value={usagePercentage} className="h-2.5" />
        </div>

        {/* App Usage */}
        <div className="space-y-3">
          {sortedAppUsage.slice(0, 5).map((app, index) => (
            <div key={app.appId}>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm flex items-center">
                  <span className={`w-3 h-3 inline-block ${getAppColor(index)} rounded-sm ml-1`}></span>
                  {app.name}
                </span>
                <span className="text-xs font-medium">
                  {formatDurationArabic(app.duration)}
                </span>
              </div>
              <Progress 
                value={calculatePercentage(app.duration, totalUsageDuration)} 
                className={`h-1.5 ${getAppColor(index)}`} 
              />
            </div>
          ))}

          {appUsage.length === 0 && (
            <div className="text-center py-4 text-slate-500">
              لا توجد بيانات استخدام
            </div>
          )}
        </div>

        {/* Time Limits Button */}
        <Dialog>
          <DialogTrigger asChild>
            <Button
              variant="outline"
              className="mt-4 w-full py-2 text-primary-600 border border-primary-200 rounded-lg hover:bg-primary-50 font-medium transition-colors"
            >
              تعديل حدود الوقت
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>تعديل حدود وقت الاستخدام</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div>
                <Label htmlFor="daily-limit">الحد اليومي (بالدقائق)</Label>
                <Input
                  id="daily-limit"
                  type="number"
                  value={dailyLimit}
                  onChange={(e) => setDailyLimit(Number(e.target.value))}
                  min={0}
                />
              </div>

              <div>
                <Label>حدود لتطبيقات محددة</Label>
                {apps.map((app: any) => (
                  <div key={app.id} className="flex items-center gap-2 mt-2">
                    <span className="text-sm flex-grow">{app.name}</span>
                    <Input
                      type="number"
                      className="w-24"
                      placeholder="دقائق"
                      value={appSpecificLimits[app.id] || ""}
                      onChange={(e) => {
                        const value = e.target.value ? Number(e.target.value) : 0;
                        setAppSpecificLimits({
                          ...appSpecificLimits,
                          [app.id]: value,
                        });
                      }}
                      min={0}
                    />
                  </div>
                ))}
              </div>

              <div className="flex justify-end gap-2 mt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    if (screenTimeLimit) {
                      setDailyLimit(screenTimeLimit.dailyLimit);
                      setAppSpecificLimits(screenTimeLimit.appSpecificLimits || {});
                    }
                  }}
                >
                  إلغاء
                </Button>
                <Button onClick={handleUpdateScreenTimeLimit}>
                  حفظ
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
