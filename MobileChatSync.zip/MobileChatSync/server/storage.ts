import {
  User, InsertUser, 
  Child, InsertChild,
  Location, InsertLocation,
  SafeZone, InsertSafeZone,
  Call, InsertCall,
  Message, InsertMessage,
  App, InsertApp,
  AppUsage, InsertAppUsage,
  Browsing, InsertBrowsing,
  Alert, InsertAlert,
  Activity, InsertActivity,
  ScreenTimeLimit, InsertScreenTimeLimit,
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Child operations
  getChild(id: number): Promise<Child | undefined>;
  getChildrenByParentId(parentId: number): Promise<Child[]>;
  createChild(child: InsertChild): Promise<Child>;
  updateChild(id: number, child: Partial<InsertChild>): Promise<Child | undefined>;
  
  // Location operations
  getLocations(childId: number, limit?: number): Promise<Location[]>;
  getLatestLocation(childId: number): Promise<Location | undefined>;
  addLocation(location: InsertLocation): Promise<Location>;
  
  // Safe zone operations
  getSafeZones(childId: number): Promise<SafeZone[]>;
  createSafeZone(safeZone: InsertSafeZone): Promise<SafeZone>;
  updateSafeZone(id: number, safeZone: Partial<InsertSafeZone>): Promise<SafeZone | undefined>;
  deleteSafeZone(id: number): Promise<boolean>;
  
  // Call operations
  getCalls(childId: number, limit?: number): Promise<Call[]>;
  addCall(call: InsertCall): Promise<Call>;
  
  // Message operations
  getMessages(childId: number, limit?: number): Promise<Message[]>;
  addMessage(message: InsertMessage): Promise<Message>;
  
  // App operations
  getApps(childId: number): Promise<App[]>;
  getApp(id: number): Promise<App | undefined>;
  addApp(app: InsertApp): Promise<App>;
  updateApp(id: number, app: Partial<InsertApp>): Promise<App | undefined>;
  
  // App usage operations
  getAppUsage(childId: number, date?: Date): Promise<AppUsage[]>;
  addAppUsage(usage: InsertAppUsage): Promise<AppUsage>;
  
  // Browsing operations
  getBrowsingHistory(childId: number, limit?: number): Promise<Browsing[]>;
  addBrowsingHistory(browsing: InsertBrowsing): Promise<Browsing>;
  
  // Alert operations
  getAlerts(childId: number, limit?: number, includeRead?: boolean): Promise<Alert[]>;
  addAlert(alert: InsertAlert): Promise<Alert>;
  markAlertAsRead(id: number): Promise<Alert | undefined>;
  
  // Activity operations
  getActivities(childId: number, limit?: number): Promise<Activity[]>;
  addActivity(activity: InsertActivity): Promise<Activity>;
  
  // Screen time limit operations
  getScreenTimeLimit(childId: number): Promise<ScreenTimeLimit | undefined>;
  setScreenTimeLimit(limit: InsertScreenTimeLimit): Promise<ScreenTimeLimit>;
  updateScreenTimeLimit(id: number, limit: Partial<InsertScreenTimeLimit>): Promise<ScreenTimeLimit | undefined>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private children: Map<number, Child>;
  private locations: Map<number, Location[]>;
  private safeZones: Map<number, SafeZone[]>;
  private calls: Map<number, Call[]>;
  private messages: Map<number, Message[]>;
  private apps: Map<number, App[]>;
  private appUsages: Map<number, AppUsage[]>;
  private browsings: Map<number, Browsing[]>;
  private alerts: Map<number, Alert[]>;
  private activities: Map<number, Activity[]>;
  private screenTimeLimits: Map<number, ScreenTimeLimit>;
  
  private userId: number;
  private childId: number;
  private locationId: number;
  private safeZoneId: number;
  private callId: number;
  private messageId: number;
  private appId: number;
  private appUsageId: number;
  private browsingId: number;
  private alertId: number;
  private activityId: number;
  private screenTimeLimitId: number;
  
  constructor() {
    this.users = new Map();
    this.children = new Map();
    this.locations = new Map();
    this.safeZones = new Map();
    this.calls = new Map();
    this.messages = new Map();
    this.apps = new Map();
    this.appUsages = new Map();
    this.browsings = new Map();
    this.alerts = new Map();
    this.activities = new Map();
    this.screenTimeLimits = new Map();
    
    this.userId = 1;
    this.childId = 1;
    this.locationId = 1;
    this.safeZoneId = 1;
    this.callId = 1;
    this.messageId = 1;
    this.appId = 1;
    this.appUsageId = 1;
    this.browsingId = 1;
    this.alertId = 1;
    this.activityId = 1;
    this.screenTimeLimitId = 1;
    
    // Initialize with demo data
    this.initializeDemoData();
  }

  private initializeDemoData() {
    // Create a demo user
    const user: User = {
      id: this.userId++,
      username: 'parent',
      password: 'password123',
      name: 'أحمد محمد',
      email: 'ahmed@example.com',
      profileImage: '',
    };
    this.users.set(user.id, user);

    // Create demo children
    const child1: Child = {
      id: this.childId++,
      name: 'سارة',
      deviceInfo: 'Samsung Galaxy S21',
      deviceId: 'device-123',
      profileImage: 'https://images.unsplash.com/photo-1499952127939-9bbf5af6c51c',
      parentId: user.id,
      createdAt: new Date(),
    };
    this.children.set(child1.id, child1);

    const child2: Child = {
      id: this.childId++,
      name: 'عمر',
      deviceInfo: 'iPhone 13',
      deviceId: 'device-456',
      profileImage: 'https://images.unsplash.com/photo-1525134479668-1bee5c7c6845',
      parentId: user.id,
      createdAt: new Date(),
    };
    this.children.set(child2.id, child2);

    // Initialize locations for first child
    const location1: Location = {
      id: this.locationId++,
      childId: child1.id,
      latitude: '25.276987',
      longitude: '55.296249',
      locationName: 'المدرسة الثانوية',
      timestamp: new Date(),
    };

    const location2: Location = {
      id: this.locationId++,
      childId: child1.id,
      latitude: '25.204849',
      longitude: '55.270782',
      locationName: 'المنزل',
      timestamp: new Date(Date.now() - 60 * 60 * 1000), // 1 hour ago
    };
    
    this.locations.set(child1.id, [location1, location2]);

    // Initialize safe zones
    const safeZone1: SafeZone = {
      id: this.safeZoneId++,
      name: 'المنزل',
      childId: child1.id,
      latitude: '25.204849',
      longitude: '55.270782',
      radius: 200,
      active: true,
    };

    const safeZone2: SafeZone = {
      id: this.safeZoneId++,
      name: 'المدرسة',
      childId: child1.id,
      latitude: '25.276987',
      longitude: '55.296249',
      radius: 300,
      active: true,
    };

    const safeZone3: SafeZone = {
      id: this.safeZoneId++,
      name: 'منزل الجدة',
      childId: child1.id,
      latitude: '25.198765',
      longitude: '55.274321',
      radius: 150,
      active: true,
    };
    
    this.safeZones.set(child1.id, [safeZone1, safeZone2, safeZone3]);

    // Initialize calls
    const call1: Call = {
      id: this.callId++,
      childId: child1.id,
      phoneNumber: '+971501234567',
      contactName: 'ماما',
      callType: 'outgoing',
      duration: 332, // 5:32 minutes
      timestamp: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
    };

    const call2: Call = {
      id: this.callId++,
      childId: child1.id,
      phoneNumber: '+971507654321',
      contactName: 'بابا',
      callType: 'incoming',
      duration: 135, // 2:15 minutes
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
    };

    const call3: Call = {
      id: this.callId++,
      childId: child1.id,
      phoneNumber: '+971503000000',
      contactName: '',
      callType: 'missed',
      duration: 0,
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
    };
    
    this.calls.set(child1.id, [call1, call2, call3]);

    // Initialize messages
    const message1: Message = {
      id: this.messageId++,
      childId: child1.id,
      phoneNumber: '+971589876543',
      contactName: 'أحمد',
      messageType: 'SMS',
      content: 'موضوع المشروع المشترك',
      timestamp: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
    };

    const message2: Message = {
      id: this.messageId++,
      childId: child1.id,
      phoneNumber: '+971581234567',
      contactName: 'سارة',
      messageType: 'SMS',
      content: 'هل أنت في المدرسة؟',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
    };
    
    this.messages.set(child1.id, [message1, message2]);

    // Initialize apps
    const app1: App = {
      id: this.appId++,
      childId: child1.id,
      name: 'Instagram',
      packageName: 'com.instagram.android',
      category: 'تطبيق اجتماعي',
      installDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
      isBlocked: false,
    };

    const app2: App = {
      id: this.appId++,
      childId: child1.id,
      name: 'WhatsApp',
      packageName: 'com.whatsapp',
      category: 'تطبيق مراسلة',
      installDate: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000), // 45 days ago
      isBlocked: false,
    };

    const app3: App = {
      id: this.appId++,
      childId: child1.id,
      name: 'TikTok',
      packageName: 'com.zhiliaoapp.musically',
      category: 'فيديو ومحتوى',
      installDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), // 15 days ago
      isBlocked: false,
    };

    const app4: App = {
      id: this.appId++,
      childId: child1.id,
      name: 'YouTube',
      packageName: 'com.google.android.youtube',
      category: 'فيديو ومحتوى',
      installDate: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000), // 60 days ago
      isBlocked: false,
    };

    const app5: App = {
      id: this.appId++,
      childId: child1.id,
      name: 'Spotify',
      packageName: 'com.spotify.music',
      category: 'موسيقى',
      installDate: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000), // 20 days ago
      isBlocked: false,
    };
    
    this.apps.set(child1.id, [app1, app2, app3, app4, app5]);

    // Initialize app usage
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const appUsage1: AppUsage = {
      id: this.appUsageId++,
      childId: child1.id,
      appId: app1.id,
      duration: 105 * 60, // 1h 45m
      date: today,
    };

    const appUsage2: AppUsage = {
      id: this.appUsageId++,
      childId: child1.id,
      appId: app3.id,
      duration: 70 * 60, // 1h 10m
      date: today,
    };

    const appUsage3: AppUsage = {
      id: this.appUsageId++,
      childId: child1.id,
      appId: app4.id,
      duration: 50 * 60, // 50m
      date: today,
    };

    const appUsage4: AppUsage = {
      id: this.appUsageId++,
      childId: child1.id,
      appId: app2.id,
      duration: 45 * 60, // 45m
      date: today,
    };

    const appUsage5: AppUsage = {
      id: this.appUsageId++,
      childId: child1.id,
      appId: 0, // Others
      duration: 55 * 60, // 55m
      date: today,
    };
    
    this.appUsages.set(child1.id, [appUsage1, appUsage2, appUsage3, appUsage4, appUsage5]);

    // Initialize browsing history
    const browsing1: Browsing = {
      id: this.browsingId++,
      childId: child1.id,
      url: 'https://www.youtube.com/watch?v=12345',
      title: 'مقطع فيديو على YouTube',
      timestamp: new Date(Date.now() - 45 * 60 * 1000), // 45 minutes ago
    };

    const browsing2: Browsing = {
      id: this.browsingId++,
      childId: child1.id,
      url: 'https://www.google.com/search?q=مشروع+العلوم',
      title: 'مشروع العلوم - بحث Google',
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
    };
    
    this.browsings.set(child1.id, [browsing1, browsing2]);

    // Initialize alerts
    const alert1: Alert = {
      id: this.alertId++,
      childId: child1.id,
      type: 'browsing',
      severity: 'danger',
      message: 'تم زيارة موقع محظور',
      details: { url: 'https://example.com/inappropriate', time: new Date().toISOString() },
      read: false,
      timestamp: new Date(Date.now() - 35 * 60 * 1000), // 35 minutes ago
    };

    const alert2: Alert = {
      id: this.alertId++,
      childId: child1.id,
      type: 'location',
      severity: 'warning',
      message: 'خروج من المنطقة الآمنة',
      details: { zoneName: 'المدرسة', time: new Date().toISOString() },
      read: false,
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
    };

    const alert3: Alert = {
      id: this.alertId++,
      childId: child1.id,
      type: 'app',
      severity: 'info',
      message: 'تطبيق جديد',
      details: { appName: 'TikTok', time: new Date().toISOString() },
      read: false,
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
    };
    
    this.alerts.set(child1.id, [alert1, alert2, alert3]);

    // Initialize activities
    const activity1: Activity = {
      id: this.activityId++,
      childId: child1.id,
      type: 'call',
      details: { contactName: 'ماما', duration: '5:32 دقيقة', callType: 'outgoing' },
      timestamp: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
    };

    const activity2: Activity = {
      id: this.activityId++,
      childId: child1.id,
      type: 'message',
      details: { contactName: 'أحمد', content: 'موضوع المشروع المشترك' },
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    };

    const activity3: Activity = {
      id: this.activityId++,
      childId: child1.id,
      type: 'browsing',
      details: { site: 'Google', search: 'مشروع العلوم' },
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
    };

    const activity4: Activity = {
      id: this.activityId++,
      childId: child1.id,
      type: 'app',
      details: { appName: 'Instagram', duration: '25 دقيقة' },
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
    };
    
    this.activities.set(child1.id, [activity1, activity2, activity3, activity4]);

    // Initialize screen time limits
    const screenTimeLimit: ScreenTimeLimit = {
      id: this.screenTimeLimitId++,
      childId: child1.id,
      dailyLimit: 360, // 6 hours
      appSpecificLimits: { [app1.id]: 120, [app3.id]: 60 }, // 2h for Instagram, 1h for TikTok
    };
    
    this.screenTimeLimits.set(child1.id, screenTimeLimit);
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const newUser: User = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }

  // Child operations
  async getChild(id: number): Promise<Child | undefined> {
    return this.children.get(id);
  }

  async getChildrenByParentId(parentId: number): Promise<Child[]> {
    return Array.from(this.children.values()).filter(child => child.parentId === parentId);
  }

  async createChild(child: InsertChild): Promise<Child> {
    const id = this.childId++;
    const newChild: Child = { ...child, id, createdAt: new Date() };
    this.children.set(id, newChild);
    
    // Initialize empty arrays for the new child
    this.locations.set(id, []);
    this.safeZones.set(id, []);
    this.calls.set(id, []);
    this.messages.set(id, []);
    this.apps.set(id, []);
    this.appUsages.set(id, []);
    this.browsings.set(id, []);
    this.alerts.set(id, []);
    this.activities.set(id, []);
    
    return newChild;
  }

  async updateChild(id: number, child: Partial<InsertChild>): Promise<Child | undefined> {
    const existingChild = this.children.get(id);
    if (!existingChild) return undefined;
    
    const updatedChild: Child = { ...existingChild, ...child };
    this.children.set(id, updatedChild);
    return updatedChild;
  }

  // Location operations
  async getLocations(childId: number, limit: number = 10): Promise<Location[]> {
    const childLocations = this.locations.get(childId) || [];
    return childLocations
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async getLatestLocation(childId: number): Promise<Location | undefined> {
    const childLocations = this.locations.get(childId) || [];
    return childLocations
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0];
  }

  async addLocation(location: InsertLocation): Promise<Location> {
    const id = this.locationId++;
    const newLocation: Location = { ...location, id };
    
    const childLocations = this.locations.get(location.childId) || [];
    childLocations.push(newLocation);
    this.locations.set(location.childId, childLocations);
    
    return newLocation;
  }

  // Safe zone operations
  async getSafeZones(childId: number): Promise<SafeZone[]> {
    return this.safeZones.get(childId) || [];
  }

  async createSafeZone(safeZone: InsertSafeZone): Promise<SafeZone> {
    const id = this.safeZoneId++;
    const newSafeZone: SafeZone = { ...safeZone, id };
    
    const childSafeZones = this.safeZones.get(safeZone.childId) || [];
    childSafeZones.push(newSafeZone);
    this.safeZones.set(safeZone.childId, childSafeZones);
    
    return newSafeZone;
  }

  async updateSafeZone(id: number, safeZone: Partial<InsertSafeZone>): Promise<SafeZone | undefined> {
    for (const [childId, safeZones] of this.safeZones.entries()) {
      const index = safeZones.findIndex(zone => zone.id === id);
      if (index !== -1) {
        const updatedSafeZone: SafeZone = { ...safeZones[index], ...safeZone };
        safeZones[index] = updatedSafeZone;
        this.safeZones.set(childId, safeZones);
        return updatedSafeZone;
      }
    }
    return undefined;
  }

  async deleteSafeZone(id: number): Promise<boolean> {
    for (const [childId, safeZones] of this.safeZones.entries()) {
      const index = safeZones.findIndex(zone => zone.id === id);
      if (index !== -1) {
        safeZones.splice(index, 1);
        this.safeZones.set(childId, safeZones);
        return true;
      }
    }
    return false;
  }

  // Call operations
  async getCalls(childId: number, limit: number = 10): Promise<Call[]> {
    const childCalls = this.calls.get(childId) || [];
    return childCalls
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async addCall(call: InsertCall): Promise<Call> {
    const id = this.callId++;
    const newCall: Call = { ...call, id };
    
    const childCalls = this.calls.get(call.childId) || [];
    childCalls.push(newCall);
    this.calls.set(call.childId, childCalls);
    
    return newCall;
  }

  // Message operations
  async getMessages(childId: number, limit: number = 10): Promise<Message[]> {
    const childMessages = this.messages.get(childId) || [];
    return childMessages
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async addMessage(message: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const newMessage: Message = { ...message, id };
    
    const childMessages = this.messages.get(message.childId) || [];
    childMessages.push(newMessage);
    this.messages.set(message.childId, childMessages);
    
    return newMessage;
  }

  // App operations
  async getApps(childId: number): Promise<App[]> {
    return this.apps.get(childId) || [];
  }

  async getApp(id: number): Promise<App | undefined> {
    for (const apps of this.apps.values()) {
      const app = apps.find(a => a.id === id);
      if (app) return app;
    }
    return undefined;
  }

  async addApp(app: InsertApp): Promise<App> {
    const id = this.appId++;
    const newApp: App = { ...app, id };
    
    const childApps = this.apps.get(app.childId) || [];
    childApps.push(newApp);
    this.apps.set(app.childId, childApps);
    
    return newApp;
  }

  async updateApp(id: number, app: Partial<InsertApp>): Promise<App | undefined> {
    for (const [childId, apps] of this.apps.entries()) {
      const index = apps.findIndex(a => a.id === id);
      if (index !== -1) {
        const updatedApp: App = { ...apps[index], ...app };
        apps[index] = updatedApp;
        this.apps.set(childId, apps);
        return updatedApp;
      }
    }
    return undefined;
  }

  // App usage operations
  async getAppUsage(childId: number, date?: Date): Promise<AppUsage[]> {
    const childAppUsages = this.appUsages.get(childId) || [];
    
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      
      return childAppUsages.filter(usage => 
        usage.date >= startOfDay && usage.date <= endOfDay
      );
    }
    
    return childAppUsages;
  }

  async addAppUsage(usage: InsertAppUsage): Promise<AppUsage> {
    const id = this.appUsageId++;
    const newUsage: AppUsage = { ...usage, id };
    
    const childAppUsages = this.appUsages.get(usage.childId) || [];
    childAppUsages.push(newUsage);
    this.appUsages.set(usage.childId, childAppUsages);
    
    return newUsage;
  }

  // Browsing operations
  async getBrowsingHistory(childId: number, limit: number = 10): Promise<Browsing[]> {
    const childBrowsing = this.browsings.get(childId) || [];
    return childBrowsing
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async addBrowsingHistory(browsing: InsertBrowsing): Promise<Browsing> {
    const id = this.browsingId++;
    const newBrowsing: Browsing = { ...browsing, id };
    
    const childBrowsing = this.browsings.get(browsing.childId) || [];
    childBrowsing.push(newBrowsing);
    this.browsings.set(browsing.childId, childBrowsing);
    
    return newBrowsing;
  }

  // Alert operations
  async getAlerts(childId: number, limit: number = 10, includeRead: boolean = false): Promise<Alert[]> {
    const childAlerts = this.alerts.get(childId) || [];
    const filteredAlerts = includeRead 
      ? childAlerts
      : childAlerts.filter(alert => !alert.read);
    
    return filteredAlerts
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async addAlert(alert: InsertAlert): Promise<Alert> {
    const id = this.alertId++;
    const newAlert: Alert = { ...alert, id, read: false };
    
    const childAlerts = this.alerts.get(alert.childId) || [];
    childAlerts.push(newAlert);
    this.alerts.set(alert.childId, childAlerts);
    
    return newAlert;
  }

  async markAlertAsRead(id: number): Promise<Alert | undefined> {
    for (const [childId, alerts] of this.alerts.entries()) {
      const index = alerts.findIndex(alert => alert.id === id);
      if (index !== -1) {
        const updatedAlert: Alert = { ...alerts[index], read: true };
        alerts[index] = updatedAlert;
        this.alerts.set(childId, alerts);
        return updatedAlert;
      }
    }
    return undefined;
  }

  // Activity operations
  async getActivities(childId: number, limit: number = 10): Promise<Activity[]> {
    const childActivities = this.activities.get(childId) || [];
    return childActivities
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async addActivity(activity: InsertActivity): Promise<Activity> {
    const id = this.activityId++;
    const newActivity: Activity = { ...activity, id };
    
    const childActivities = this.activities.get(activity.childId) || [];
    childActivities.push(newActivity);
    this.activities.set(activity.childId, childActivities);
    
    return newActivity;
  }

  // Screen time limit operations
  async getScreenTimeLimit(childId: number): Promise<ScreenTimeLimit | undefined> {
    return this.screenTimeLimits.get(childId);
  }

  async setScreenTimeLimit(limit: InsertScreenTimeLimit): Promise<ScreenTimeLimit> {
    const id = this.screenTimeLimitId++;
    const newLimit: ScreenTimeLimit = { ...limit, id };
    this.screenTimeLimits.set(limit.childId, newLimit);
    return newLimit;
  }

  async updateScreenTimeLimit(id: number, limit: Partial<InsertScreenTimeLimit>): Promise<ScreenTimeLimit | undefined> {
    for (const [childId, screenTimeLimit] of this.screenTimeLimits.entries()) {
      if (screenTimeLimit.id === id) {
        const updatedLimit: ScreenTimeLimit = { ...screenTimeLimit, ...limit };
        this.screenTimeLimits.set(childId, updatedLimit);
        return updatedLimit;
      }
    }
    return undefined;
  }
}

export const storage = new MemStorage();
