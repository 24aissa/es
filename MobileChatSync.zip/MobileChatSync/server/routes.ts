import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertChildSchema, 
  insertLocationSchema,
  insertSafeZoneSchema,
  insertCallSchema,
  insertMessageSchema,
  insertAppSchema,
  insertAppUsageSchema,
  insertBrowsingSchema,
  insertAlertSchema,
  insertActivitySchema,
  insertScreenTimeLimitSchema
} from "@shared/schema";
import { z } from "zod";

// Helper function to validate request body against a schema
function validate<T>(schema: z.ZodType<T>, body: unknown): T {
  const result = schema.safeParse(body);
  if (!result.success) {
    throw new Error(`Validation error: ${result.error.message}`);
  }
  return result.data;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      // In a real app, you'd use proper authentication with JWT or sessions
      res.json({ user: { id: user.id, username: user.username, name: user.name, email: user.email } });
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  // User routes
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = validate(insertUserSchema, req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  // Child routes
  app.get("/api/children", async (req: Request, res: Response) => {
    try {
      const parentId = parseInt(req.query.parentId as string);
      if (isNaN(parentId)) {
        return res.status(400).json({ message: "Valid parentId parameter is required" });
      }
      const children = await storage.getChildrenByParentId(parentId);
      res.json(children);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/children", async (req: Request, res: Response) => {
    try {
      const childData = validate(insertChildSchema, req.body);
      const child = await storage.createChild(childData);
      res.status(201).json(child);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  app.get("/api/children/:id", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const child = await storage.getChild(childId);
      if (!child) {
        return res.status(404).json({ message: "Child not found" });
      }
      res.json(child);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.patch("/api/children/:id", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const childData = req.body;
      const updatedChild = await storage.updateChild(childId, childData);
      if (!updatedChild) {
        return res.status(404).json({ message: "Child not found" });
      }
      res.json(updatedChild);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Location routes
  app.get("/api/children/:id/locations", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const locations = await storage.getLocations(childId, limit);
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.get("/api/children/:id/locations/latest", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const location = await storage.getLatestLocation(childId);
      if (!location) {
        return res.status(404).json({ message: "No location data found" });
      }
      res.json(location);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/locations", async (req: Request, res: Response) => {
    try {
      const locationData = validate(insertLocationSchema, req.body);
      const location = await storage.addLocation(locationData);
      res.status(201).json(location);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Safe Zone routes
  app.get("/api/children/:id/safe-zones", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const safeZones = await storage.getSafeZones(childId);
      res.json(safeZones);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/safe-zones", async (req: Request, res: Response) => {
    try {
      const safeZoneData = validate(insertSafeZoneSchema, req.body);
      const safeZone = await storage.createSafeZone(safeZoneData);
      res.status(201).json(safeZone);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  app.patch("/api/safe-zones/:id", async (req: Request, res: Response) => {
    try {
      const safeZoneId = parseInt(req.params.id);
      const safeZoneData = req.body;
      const updatedSafeZone = await storage.updateSafeZone(safeZoneId, safeZoneData);
      if (!updatedSafeZone) {
        return res.status(404).json({ message: "Safe zone not found" });
      }
      res.json(updatedSafeZone);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  app.delete("/api/safe-zones/:id", async (req: Request, res: Response) => {
    try {
      const safeZoneId = parseInt(req.params.id);
      const success = await storage.deleteSafeZone(safeZoneId);
      if (!success) {
        return res.status(404).json({ message: "Safe zone not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  // Call routes
  app.get("/api/children/:id/calls", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const calls = await storage.getCalls(childId, limit);
      res.json(calls);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/calls", async (req: Request, res: Response) => {
    try {
      const callData = validate(insertCallSchema, req.body);
      const call = await storage.addCall(callData);
      res.status(201).json(call);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Message routes
  app.get("/api/children/:id/messages", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const messages = await storage.getMessages(childId, limit);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/messages", async (req: Request, res: Response) => {
    try {
      const messageData = validate(insertMessageSchema, req.body);
      const message = await storage.addMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // App routes
  app.get("/api/children/:id/apps", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const apps = await storage.getApps(childId);
      res.json(apps);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/apps", async (req: Request, res: Response) => {
    try {
      const appData = validate(insertAppSchema, req.body);
      const app = await storage.addApp(appData);
      res.status(201).json(app);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  app.patch("/api/apps/:id", async (req: Request, res: Response) => {
    try {
      const appId = parseInt(req.params.id);
      const appData = req.body;
      const updatedApp = await storage.updateApp(appId, appData);
      if (!updatedApp) {
        return res.status(404).json({ message: "App not found" });
      }
      res.json(updatedApp);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // App Usage routes
  app.get("/api/children/:id/app-usage", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      let date = undefined;
      if (req.query.date) {
        date = new Date(req.query.date as string);
      }
      const appUsage = await storage.getAppUsage(childId, date);
      res.json(appUsage);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/app-usage", async (req: Request, res: Response) => {
    try {
      const usageData = validate(insertAppUsageSchema, req.body);
      const usage = await storage.addAppUsage(usageData);
      res.status(201).json(usage);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Browsing History routes
  app.get("/api/children/:id/browsing", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const browsing = await storage.getBrowsingHistory(childId, limit);
      res.json(browsing);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/browsing", async (req: Request, res: Response) => {
    try {
      const browsingData = validate(insertBrowsingSchema, req.body);
      const browsing = await storage.addBrowsingHistory(browsingData);
      res.status(201).json(browsing);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Alert routes
  app.get("/api/children/:id/alerts", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const includeRead = req.query.includeRead === 'true';
      const alerts = await storage.getAlerts(childId, limit, includeRead);
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/alerts", async (req: Request, res: Response) => {
    try {
      const alertData = validate(insertAlertSchema, req.body);
      const alert = await storage.addAlert(alertData);
      res.status(201).json(alert);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  app.patch("/api/alerts/:id/read", async (req: Request, res: Response) => {
    try {
      const alertId = parseInt(req.params.id);
      const updatedAlert = await storage.markAlertAsRead(alertId);
      if (!updatedAlert) {
        return res.status(404).json({ message: "Alert not found" });
      }
      res.json(updatedAlert);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Activity routes
  app.get("/api/children/:id/activities", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const activities = await storage.getActivities(childId, limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/activities", async (req: Request, res: Response) => {
    try {
      const activityData = validate(insertActivitySchema, req.body);
      const activity = await storage.addActivity(activityData);
      res.status(201).json(activity);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Screen Time Limit routes
  app.get("/api/children/:id/screen-time-limit", async (req: Request, res: Response) => {
    try {
      const childId = parseInt(req.params.id);
      const limit = await storage.getScreenTimeLimit(childId);
      if (!limit) {
        return res.status(404).json({ message: "Screen time limit not found" });
      }
      res.json(limit);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/screen-time-limits", async (req: Request, res: Response) => {
    try {
      const limitData = validate(insertScreenTimeLimitSchema, req.body);
      const limit = await storage.setScreenTimeLimit(limitData);
      res.status(201).json(limit);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  app.patch("/api/screen-time-limits/:id", async (req: Request, res: Response) => {
    try {
      const limitId = parseInt(req.params.id);
      const limitData = req.body;
      const updatedLimit = await storage.updateScreenTimeLimit(limitId, limitData);
      if (!updatedLimit) {
        return res.status(404).json({ message: "Screen time limit not found" });
      }
      res.json(updatedLimit);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
